"""
PulseGPT — evaluate.py
=======================
论文核心评估脚本，实现以下指标：

1. Pitch Class Entropy (PCE)        — 旋律音高多样性
2. Groove Consistency (GC)          — 节奏稳定性（跨小节 onset 模式的一致性）
3. Scale Consistency (SC)           — 音符调性契合度
4. Multi-track Rate (MTR)           — 多轨生成率（论文数据集贡献指标）
5. Energy Arc Alignment (EAA) ★     — 【独创指标】生成能量弧线与目标弧线的 DTW 距离

使用方法:
  # 评估单个生成文件（与目标能量弧线对比）
  python evaluate.py --file generated.mid --target_struct DROP

  # 批量评估并输出论文所需的 LaTeX 表格
  python evaluate.py --batch --dir outputs/
"""

import argparse
import os
import glob
import json
import numpy as np
import pretty_midi
from scipy.spatial.distance import cosine
from collections import defaultdict

# ──────────────────────────────────────────────────────────────────────────────
# 1. 工具类：MIDI 特征提取器
# ──────────────────────────────────────────────────────────────────────────────

class MIDIFeatureExtractor:
    def __init__(self, midi_path: str):
        self.path = midi_path
        try:
            self.pm = pretty_midi.PrettyMIDI(midi_path)
        except Exception as e:
            print(f"[ERROR] 无法加载 {midi_path}: {e}")
            self.pm = None

    def get_all_notes(self, exclude_drums=False):
        """获取所有音符"""
        if not self.pm:
            return []
        notes = []
        for inst in self.pm.instruments:
            if exclude_drums and inst.is_drum:
                continue
            notes.extend(inst.notes)
        return sorted(notes, key=lambda n: n.start)

    def get_bar_boundaries(self, bpm=128):
        """计算小节边界（假设 4/4 拍）"""
        if not self.pm:
            return []
        try:
            beats = self.pm.get_beats()
            if len(beats) < 4:
                return []
            bars = []
            for i in range(0, len(beats) - 4, 4):
                bars.append((beats[i], beats[i + 4]))
            return bars
        except:
            beat_dur = 60.0 / bpm
            bar_dur = beat_dur * 4
            end_time = self.pm.get_end_time()
            n_bars = max(1, int(end_time / bar_dur))
            return [(i * bar_dur, (i + 1) * bar_dur) for i in range(n_bars)]

    def get_track_types(self):
        """返回当前 MIDI 中存在的轨道类型集合"""
        if not self.pm:
            return set()
        types = set()
        for inst in self.pm.instruments:
            name = inst.name.upper()
            if inst.is_drum or 'DRUM' in name:
                types.add('DRUMS')
            elif 'BASS' in name:
                types.add('BASS')
            elif 'CHORD' in name or 'PAD' in name:
                types.add('CHORD')
            elif 'MELODY' in name or 'LEAD' in name:
                types.add('MELODY')
            else:
                types.add('OTHER')
        return types


# ──────────────────────────────────────────────────────────────────────────────
# 2. Pitch Class Entropy (PCE)
# ──────────────────────────────────────────────────────────────────────────────

def pitch_class_entropy(midi_path: str) -> float:
    """
    计算旋律音高多样性（Shannon 熵）
    高熵 = 音符分布均匀（多样）；低熵 = 音符集中（单调）
    理想的生成片段应接近训练集的参考熵值（约 2.5-3.5 bits）

    Returns:
        entropy: float，单位 bits；-1.0 表示无法计算
    """
    extractor = MIDIFeatureExtractor(midi_path)
    notes = extractor.get_all_notes(exclude_drums=True)
    if not notes:
        return -1.0

    # 12维音高类别直方图
    pitch_hist = np.zeros(12)
    for n in notes:
        pitch_hist[n.pitch % 12] += 1

    # 归一化为概率分布
    total = pitch_hist.sum()
    if total == 0:
        return -1.0
    pitch_prob = pitch_hist / total

    # Shannon 熵
    nonzero = pitch_prob[pitch_prob > 0]
    entropy = -np.sum(nonzero * np.log2(nonzero))
    return float(entropy)


# ──────────────────────────────────────────────────────────────────────────────
# 3. Groove Consistency (GC)
# ──────────────────────────────────────────────────────────────────────────────

def groove_consistency(midi_path: str, resolution: int = 16) -> float:
    """
    计算节奏稳定性：相邻小节的 onset 模式相似度的平均值。
    1.0 = 完全相同（极度重复，Techno 正常）；0.0 = 完全不同（混乱）

    原理：将每个小节映射为 16 步的二值 onset 向量，计算相邻小节的余弦相似度。

    Returns:
        gc: float [0.0, 1.0]；-1.0 表示无法计算
    """
    extractor = MIDIFeatureExtractor(midi_path)
    bars = extractor.get_bar_boundaries()
    notes = extractor.get_all_notes()

    if len(bars) < 2 or not notes:
        return -1.0

    def bar_onset_vector(bar_start, bar_end):
        """生成 16 步二值 onset 向量"""
        bar_dur = bar_end - bar_start
        vec = np.zeros(resolution)
        bar_notes = [n for n in notes if bar_start <= n.start < bar_end]
        for n in bar_notes:
            rel = (n.start - bar_start) / bar_dur
            step = min(int(rel * resolution), resolution - 1)
            vec[step] = 1.0
        return vec

    # 计算相邻小节的余弦相似度
    similarities = []
    prev_vec = bar_onset_vector(*bars[0])
    for bar in bars[1:]:
        curr_vec = bar_onset_vector(*bar)
        if prev_vec.sum() == 0 and curr_vec.sum() == 0:
            similarities.append(1.0)  # 两个空小节视为相同
        elif prev_vec.sum() == 0 or curr_vec.sum() == 0:
            similarities.append(0.0)
        else:
            sim = 1.0 - cosine(prev_vec, curr_vec)
            similarities.append(max(0.0, sim))
        prev_vec = curr_vec

    return float(np.mean(similarities))


# ──────────────────────────────────────────────────────────────────────────────
# 4. Scale Consistency (SC)
# ──────────────────────────────────────────────────────────────────────────────

# 常用调式的音阶音符（相对于主音的半音数）
SCALE_TEMPLATES = {
    'MAJOR':  {0, 2, 4, 5, 7, 9, 11},
    'MINOR':  {0, 2, 3, 5, 7, 8, 10},
    'DORIAN': {0, 2, 3, 5, 7, 9, 10},
}

NOTE_NAMES = {'C': 0, 'C#': 1, 'D': 2, 'D#': 3, 'E': 4, 'F': 5,
              'F#': 6, 'G': 7, 'G#': 8, 'A': 9, 'A#': 10, 'B': 11}

def scale_consistency(midi_path: str, key: str = 'C_MINOR') -> float:
    """
    计算音符在调式内的占比（调性契合度）
    例：key='A_MINOR' → 检查所有旋律音符是否属于 A 自然小调

    Returns:
        sc: float [0.0, 1.0]；1.0 = 全部在调内；-1.0 = 无法计算
    """
    extractor = MIDIFeatureExtractor(midi_path)
    notes = extractor.get_all_notes(exclude_drums=True)
    if not notes:
        return -1.0

    # 解析 key 字符串，e.g., "A_MINOR", "C#_MAJOR"
    parts = key.upper().split('_')
    root_name = parts[0].replace('SHARP', '#')
    mode = parts[1] if len(parts) > 1 else 'MINOR'

    root_pc = NOTE_NAMES.get(root_name, 0)
    scale_pcs = {(root_pc + interval) % 12 for interval in SCALE_TEMPLATES.get(mode, SCALE_TEMPLATES['MINOR'])}

    in_scale = sum(1 for n in notes if (n.pitch % 12) in scale_pcs)
    return float(in_scale / len(notes))


# ──────────────────────────────────────────────────────────────────────────────
# 5. Multi-Track Rate (MTR)
# ──────────────────────────────────────────────────────────────────────────────

def multi_track_rate(midi_path: str) -> dict:
    """
    分析生成文件的多轨组成情况

    Returns:
        dict: {
            'n_tracks': int,
            'track_types': list[str],
            'has_drums': bool,
            'has_bass': bool,
            'has_harmony': bool,   # CHORD 或 MELODY
        }
    """
    extractor = MIDIFeatureExtractor(midi_path)
    types = extractor.get_track_types()
    return {
        'n_tracks':    len(types),
        'track_types': sorted(types),
        'has_drums':   'DRUMS' in types,
        'has_bass':    'BASS' in types,
        'has_harmony': 'CHORD' in types or 'MELODY' in types,
    }


# ──────────────────────────────────────────────────────────────────────────────
# 6. Energy Arc Alignment (EAA) ★ — 论文独创指标
# ──────────────────────────────────────────────────────────────────────────────

def compute_energy_curve(midi_path: str, bpm: int = 128) -> np.ndarray:
    """
    计算 MIDI 文件的逐小节能量曲线 D_t
    使用与 dataset_processor.py 一致的公式：
        D_t = 0.35*norm_density + 0.35*mean_vel + 0.20*norm_kick + 0.10*mean_pitch

    Returns:
        curve: np.ndarray，每小节一个能量值 [0.0, 1.0]
    """
    extractor = MIDIFeatureExtractor(midi_path)
    if not extractor.pm:
        return np.array([])

    bars = extractor.get_bar_boundaries(bpm=bpm)
    if not bars:
        return np.array([])

    ALPHA, BETA, GAMMA, DELTA = 0.35, 0.35, 0.20, 0.10
    GLOBAL_MAX_DENSITY = 40.0
    GLOBAL_MAX_KICK = 8.0

    curve = []
    for bar_start, bar_end in bars:
        bar_notes = []
        drum_notes = []
        for inst in extractor.pm.instruments:
            for n in inst.notes:
                if bar_start <= n.start < bar_end:
                    bar_notes.append(n)
                    if inst.is_drum:
                        drum_notes.append(n)

        density = len(bar_notes)
        if bar_notes:
            mean_vel = np.mean([n.velocity for n in bar_notes]) / 127.0
            melodic = [n.pitch for n in bar_notes if n not in drum_notes]
            mean_pitch = np.mean(melodic) / 127.0 if melodic else 0.0
        else:
            mean_vel = 0.0
            mean_pitch = 0.0

        kick_count = sum(1 for n in drum_notes if n.pitch in [35, 36])

        norm_density = min(density / GLOBAL_MAX_DENSITY, 1.0)
        norm_kick = min(kick_count / GLOBAL_MAX_KICK, 1.0)

        d_t = ALPHA * norm_density + BETA * mean_vel + GAMMA * norm_kick + DELTA * mean_pitch
        curve.append(d_t)

    return np.array(curve)


def dtw_distance(seq_a: np.ndarray, seq_b: np.ndarray) -> float:
    """
    计算两条能量曲线之间的 DTW（动态时间规整）距离
    DTW 允许两条曲线在时间轴上有弹性对齐，比欧氏距离更鲁棒

    Returns:
        distance: float，越小说明两条曲线越相似；0.0 = 完全相同
    """
    n, m = len(seq_a), len(seq_b)
    if n == 0 or m == 0:
        return float('inf')

    # 初始化 DTW 矩阵
    dtw = np.full((n + 1, m + 1), np.inf)
    dtw[0, 0] = 0.0

    for i in range(1, n + 1):
        for j in range(1, m + 1):
            cost = abs(seq_a[i - 1] - seq_b[j - 1])
            dtw[i, j] = cost + min(dtw[i - 1, j],     # 插入
                                   dtw[i, j - 1],     # 删除
                                   dtw[i - 1, j - 1]) # 匹配
    # 归一化（除以路径长度）
    return float(dtw[n, m] / (n + m))


# 各段落的理想能量目标弧线（论文 Table 1 中的 Ground Truth）
STRUCT_TARGET_CURVES = {
    'INTRO':     np.array([0.2, 0.3, 0.3, 0.4, 0.4, 0.45, 0.5, 0.5]),
    'BUILDUP':   np.array([0.45, 0.5, 0.55, 0.6, 0.65, 0.7, 0.75, 0.8]),
    'DROP':      np.array([0.8, 0.85, 0.85, 0.9, 0.9, 0.85, 0.85, 0.8]),
    'BREAKDOWN': np.array([0.4, 0.35, 0.3, 0.3, 0.3, 0.35, 0.35, 0.4]),
    'OUTRO':     np.array([0.5, 0.45, 0.4, 0.35, 0.3, 0.25, 0.2, 0.15]),
    'PATTERN':   np.array([0.6, 0.65, 0.65, 0.6, 0.65, 0.7, 0.65, 0.65]),
}

def energy_arc_alignment(midi_path: str, target_struct: str = 'DROP', bpm: int = 128) -> dict:
    """
    【论文核心指标 — Energy Arc Alignment (EAA)】

    计算生成 MIDI 的能量弧线与该段落的目标能量模板之间的 DTW 距离。
    距离越小，说明模型生成的能量走势与真实 EDM 段落规律越一致。

    Args:
        midi_path:     生成的 MIDI 文件路径
        target_struct: 目标段落类型（'DROP', 'INTRO', 'BREAKDOWN' 等）
        bpm:           BPM

    Returns:
        dict: {
            'eaa_distance':    DTW 距离（越低越好）
            'generated_curve': 生成文件的能量曲线
            'target_curve':    目标能量曲线
            'n_bars':          生成文件的小节数
        }
    """
    generated_curve = compute_energy_curve(midi_path, bpm=bpm)
    target_struct = target_struct.upper()
    target_curve = STRUCT_TARGET_CURVES.get(target_struct, STRUCT_TARGET_CURVES['PATTERN'])

    if len(generated_curve) == 0:
        return {'eaa_distance': float('inf'), 'generated_curve': [], 'target_curve': target_curve.tolist(), 'n_bars': 0}

    distance = dtw_distance(generated_curve, target_curve)

    return {
        'eaa_distance':    round(distance, 4),
        'generated_curve': [round(v, 3) for v in generated_curve.tolist()],
        'target_curve':    [round(v, 3) for v in target_curve.tolist()],
        'n_bars':          len(generated_curve),
    }


# ──────────────────────────────────────────────────────────────────────────────
# 7. 综合评估器
# ──────────────────────────────────────────────────────────────────────────────

def evaluate_midi(midi_path: str, key: str = 'C_MINOR', struct: str = 'DROP', bpm: int = 128) -> dict:
    """
    对单个 MIDI 文件运行所有评估指标

    Returns:
        完整评估结果 dict
    """
    print(f"\n{'─'*60}")
    print(f"  评估文件: {os.path.basename(midi_path)}")
    print(f"  参数: Key={key}, Struct={struct}, BPM={bpm}")
    print(f"{'─'*60}")

    results = {
        'file':   os.path.basename(midi_path),
        'key':    key,
        'struct': struct,
        'bpm':    bpm,
    }

    # PCE
    pce = pitch_class_entropy(midi_path)
    results['pce'] = round(pce, 4)
    print(f"  [PCE]  Pitch Class Entropy    : {pce:.4f} bits  (参考: 2.5-3.5 为佳)")

    # GC
    gc = groove_consistency(midi_path)
    results['gc'] = round(gc, 4)
    print(f"  [GC]   Groove Consistency     : {gc:.4f}        (越接近 1.0 节奏越稳定)")

    # SC
    sc = scale_consistency(midi_path, key=key)
    results['sc'] = round(sc, 4)
    print(f"  [SC]   Scale Consistency      : {sc:.4f}        (越接近 1.0 调性越准确)")

    # MTR
    mtr = multi_track_rate(midi_path)
    results.update({f'mtr_{k}': v for k, v in mtr.items()})
    print(f"  [MTR]  Multi-track: {mtr['n_tracks']} 轨 | 类型: {mtr['track_types']}")
    print(f"          Drums: {'Y' if mtr['has_drums'] else 'N'}  Bass: {'Y' if mtr['has_bass'] else 'N'}  Harmony: {'Y' if mtr['has_harmony'] else 'N'}")

    # EAA ★
    eaa = energy_arc_alignment(midi_path, target_struct=struct, bpm=bpm)
    results['eaa_distance'] = eaa['eaa_distance']
    results['eaa_n_bars']   = eaa['n_bars']
    print(f"  [EAA ★] Energy Arc Alignment  : DTW = {eaa['eaa_distance']:.4f}  (越低越好, 0=完美对齐)")
    print(f"          生成曲线 ({eaa['n_bars']} 小节): {eaa['generated_curve'][:8]}")
    print(f"          目标曲线 ({struct}):         {eaa['target_curve']}")

    return results


def batch_evaluate(directory: str, struct: str = 'DROP', bpm: int = 128):
    """批量评估目录下所有 MIDI 文件，输出统计摘要"""
    files = glob.glob(os.path.join(directory, '*.mid'))
    if not files:
        print(f"[WARN] 目录 {directory} 下没有找到 .mid 文件")
        return

    print(f"\n{'='*60}")
    print(f"  PulseGPT 批量评估  |  目录: {directory}")
    print(f"  共 {len(files)} 个文件  |  参数: Struct={struct}, BPM={bpm}")
    print(f"{'='*60}")

    all_results = []
    for f in sorted(files):
        # 尝试从文件名推断 key 和 struct
        fname = os.path.basename(f).upper()
        key = 'C_MINOR'
        for note in ['A#', 'G#', 'F#', 'D#', 'C#', 'A', 'B', 'C', 'D', 'E', 'F', 'G']:
            if f'KEY{note}' in fname or f'KEY_{note}' in fname:
                mode = 'MINOR' if 'MINOR' in fname else 'MAJOR'
                key = f'{note}_{mode}'
                break
        for s in ['DROP', 'INTRO', 'BREAKDOWN', 'OUTRO', 'BUILDUP', 'PATTERN']:
            if s in fname:
                struct = s
                break

        r = evaluate_midi(f, key=key, struct=struct, bpm=bpm)
        all_results.append(r)

    # 统计摘要
    valid = [r for r in all_results if r['pce'] != -1.0]
    if valid:
        print(f"\n{'='*60}")
        print(f"  批量评估摘要（共 {len(valid)} 个有效文件）")
        print(f"{'='*60}")
        print(f"  PCE  均值: {np.mean([r['pce'] for r in valid]):.4f}  ±  {np.std([r['pce'] for r in valid]):.4f}")
        print(f"  GC   均值: {np.mean([r['gc'] for r in valid if r['gc'] != -1.0]):.4f}")
        print(f"  SC   均值: {np.mean([r['sc'] for r in valid if r['sc'] != -1.0]):.4f}")
        print(f"  EAA  均值: {np.mean([r['eaa_distance'] for r in valid]):.4f}  (越低越好)")
        multi = [r for r in valid if r['mtr_n_tracks'] > 1]
        print(f"  MTR  多轨率: {len(multi)}/{len(valid)} = {len(multi)/len(valid)*100:.1f}%")

    # 保存 JSON 详细结果
    out_path = os.path.join(directory, 'eval_results.json')
    with open(out_path, 'w', encoding='utf-8') as f:
        json.dump(all_results, f, ensure_ascii=False, indent=2)
    print(f"\n  详细结果已保存: {out_path}")

    return all_results


# ──────────────────────────────────────────────────────────────────────────────
# 8. 主入口
# ──────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='PulseGPT MIDI Evaluator')
    parser.add_argument('--file',          type=str, help='单个 MIDI 文件路径')
    parser.add_argument('--batch',         action='store_true', help='批量评估模式')
    parser.add_argument('--dir',           type=str, default='.', help='批量评估目录')
    parser.add_argument('--key',           type=str, default='C_MINOR', help='调性 e.g. A_MINOR')
    parser.add_argument('--target_struct', type=str, default='DROP', help='目标段落结构')
    parser.add_argument('--bpm',           type=int, default=128, help='BPM')
    args = parser.parse_args()

    # 安装检查
    try:
        from scipy.spatial.distance import cosine
    except ImportError:
        print("[ERROR] 缺少 scipy，请运行: pip install scipy")
        exit(1)

    if args.batch:
        batch_evaluate(args.dir, struct=args.target_struct, bpm=args.bpm)
    elif args.file:
        evaluate_midi(args.file, key=args.key, struct=args.target_struct, bpm=args.bpm)
    else:
        # 默认：评估刚生成的测试文件
        test_file = "techno_130bpm_post_train.mid"
        if os.path.exists(test_file):
            print("未指定参数，自动评估最新生成文件...")
            evaluate_midi(test_file, key='C_MINOR', struct='PATTERN', bpm=130)
        else:
            print("用法: python evaluate.py --file your_output.mid --key A_MINOR --target_struct DROP")
            parser.print_help()
