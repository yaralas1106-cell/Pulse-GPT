import os

replacements = {
    "PulseGPT": "PulseGPT",
    "PulseGPT": "PulseGPT",
    "Pulse": "Pulse",
    "Pulse": "Pulse",
    "pulse": "pulse",
    "PulseGPT": "PulseGPT",
    "pulsegpt": "pulsegpt",
}

def process_file(filepath):
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
    except UnicodeDecodeError:
        return
    
    orig_content = content
    for k, v in replacements.items():
        content = content.replace(k, v)
        
    if content != orig_content:
        with open(filepath, 'w', encoding='utf-8') as f:
            f.write(content)
        print(f"Updated content in {filepath}")

# 遍历目录
target_dir = r"d:\BigData\PycharmProject\PulseGPT"
for root, dirs, files in os.walk(target_dir):
    # 跳过虚拟环境等目录
    if ".git" in root or ".venv" in root or "venv" in root or "env" in root:
        continue
    for file in files:
        if file.endswith(".py") or file.endswith(".md") or file.endswith(".json") or file.endswith(".jsonl"):
            process_file(os.path.join(root, file))

# 特殊处理 Research Proposal
research_doc = r"C:\Users\YaRa\.gemini\antigravity\brain\23fe0b03-304a-4937-9c92-28ec66668e81\research_proposal.md"
if os.path.exists(research_doc):
    process_file(research_doc)

# 阶段2: 重命名受影响的文件
for root, dirs, files in os.walk(target_dir):
    if ".git" in root or ".venv" in root or "venv" in root or "env" in root:
        continue
    for file in files:
        if "pulse" in file.lower() or "pulsegpt" in file.lower():
            p_old = os.path.join(root, file)
            new_file = file
            for k, v in replacements.items():
                new_file = new_file.replace(k, v)
            p_new = os.path.join(root, new_file)
            os.rename(p_old, p_new)
            print(f"Renamed file {file} -> {new_file}")

print("替换任务完成！")
