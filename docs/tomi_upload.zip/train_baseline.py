"""
PulseGPT — train_baseline.py
==============================
Baseline 对照实验：用完全相同的模型架构，
但剥除所有控制 Token（GENRE / STRUCT / ENERGY / KEY / BPM / SECTION），
只保留纯音符序列进行训练。

用途：与 PulseGPT 的指标结果对比，证明控制标签体系的有效性。

论文中对应：
  Table 2, Row "Baseline (Uncontrolled)"
"""

import json
import re
import time
import torch
from torch.optim import AdamW
from torch.optim.lr_scheduler import CosineAnnealingLR
from torch.utils.data import Dataset, DataLoader

from tokenizer import PulseTokenizer
from model import PulseLlamaModel

# ──────────────────────────────────────────────────────────────────────────────
# 1. Baseline 数据集：剥除所有控制 Token
# ──────────────────────────────────────────────────────────────────────────────

# 需要剥除的控制 Token 的正则模式
CONTROL_TOKEN_PATTERNS = [
    re.compile(r'^\[GENRE_'),       # [GENRE_HOUSE], [GENRE_TECHNO]...
    re.compile(r'^\[STRUCT_'),      # [STRUCT_DROP], [STRUCT_INTRO]...
    re.compile(r'^\[SECTION_'),     # [SECTION_1], [SECTION_2]...
    re.compile(r'^\[KEY_'),         # [KEY_C_MINOR], [KEY_A_MAJOR]...
    re.compile(r'^\[BPM_'),         # [BPM_128], [BPM_130]...
    re.compile(r'^\[ENERGY_LEVEL_'), # [ENERGY_LEVEL_3]...
]

def is_control_token(token: str) -> bool:
    """判断是否为需要剥除的控制 Token"""
    return any(pat.match(token) for pat in CONTROL_TOKEN_PATTERNS)

def strip_control_tokens(sequence: list) -> list:
    """从 Token 序列中剥除所有控制 Token，只保留音符内容"""
    return [t for t in sequence if not is_control_token(t)]


class BaselineDataset(Dataset):
    """
    从同一个 pulse_dataset.jsonl 加载数据，
    但在输入前剥除所有控制 Token。
    """
    def __init__(self, jsonl_path: str, tokenizer: PulseTokenizer, max_seq_len: int = 1024):
        self.tokenizer = tokenizer
        self.max_seq_len = max_seq_len
        self.samples = []

        skipped = 0
        with open(jsonl_path, 'r', encoding='utf-8') as f:
            for line in f:
                if not line.strip():
                    continue
                seq = json.loads(line)
                if not isinstance(seq, list):
                    continue
                # 剥除控制 Token
                stripped = strip_control_tokens(seq)
                # 过滤掉太短的序列（剥除后可能只剩几个 Token）
                if len(stripped) < 10:
                    skipped += 1
                    continue
                self.samples.append(stripped)

        print(f"  Baseline 数据集: {len(self.samples)} 个有效样本（跳过 {skipped} 个过短序列）")

        # 打印一个样本示例，确认控制 Token 已被移除
        if self.samples:
            example = self.samples[0][:12]
            print(f"  样本示例（前12个Token）: {example}")

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        seq = self.samples[idx]
        token_ids = self.tokenizer.encode(seq, add_bos=True, add_eos=True)
        if len(token_ids) > self.max_seq_len:
            token_ids = token_ids[:self.max_seq_len - 1] + [self.tokenizer.eos_id]
        return torch.tensor(token_ids, dtype=torch.long)


def collate_fn(batch, pad_id):
    batch.sort(key=lambda x: len(x), reverse=True)
    max_len = max(len(t) for t in batch)
    input_ids = torch.full((len(batch), max_len), pad_id, dtype=torch.long)
    attention_mask = torch.zeros((len(batch), max_len), dtype=torch.long)
    for i, seq in enumerate(batch):
        l = len(seq)
        input_ids[i, :l] = seq
        attention_mask[i, :l] = 1
    labels = input_ids.clone()
    labels[labels == pad_id] = -100
    return {'input_ids': input_ids, 'attention_mask': attention_mask, 'labels': labels}


# ──────────────────────────────────────────────────────────────────────────────
# 2. Baseline 训练
# ──────────────────────────────────────────────────────────────────────────────

def train_baseline():
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"[{time.strftime('%H:%M:%S')}] Baseline 训练启动 | 设备: {device}")

    # 同一个词表（保证公平对比）
    tokenizer = PulseTokenizer()
    print(f"[{time.strftime('%H:%M:%S')}] 词表: {len(tokenizer)} tokens")

    dataset = BaselineDataset(
        jsonl_path="dataset/processed/pulse_dataset.jsonl",
        tokenizer=tokenizer,
        max_seq_len=1024
    )

    loader = DataLoader(
        dataset,
        batch_size=4,
        shuffle=True,
        collate_fn=lambda b: collate_fn(b, pad_id=tokenizer.pad_id)
    )

    # 完全相同的模型架构（公平对比的关键）
    model = PulseLlamaModel(vocab_size=len(tokenizer), pad_token_id=tokenizer.pad_id).to(device)
    total_params = sum(p.numel() for p in model.parameters()) / 1e6
    print(f"[{time.strftime('%H:%M:%S')}] 模型初始化 | 参数量: {total_params:.2f} M（与 PulseGPT 相同）")

    epochs = 200
    optimizer = AdamW(model.parameters(), lr=5e-4, weight_decay=0.01)
    scheduler = CosineAnnealingLR(optimizer, T_max=epochs, eta_min=1e-5)

    print(f"\n============== Baseline 无控制训练 ({epochs} Epochs) ==============")
    print(f"  注意：控制 Token 已全部剥除，模型无法感知 Genre/Struct/Energy\n")

    model.train()
    best_loss = float('inf')
    best_epoch = 0

    for epoch in range(1, epochs + 1):
        epoch_loss = 0.0
        steps = 0

        for batch in loader:
            optimizer.zero_grad()
            input_ids      = batch['input_ids'].to(device)
            attention_mask = batch['attention_mask'].to(device)
            labels         = batch['labels'].to(device)

            loss, _ = model(input_ids, attention_mask, labels)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            optimizer.step()

            epoch_loss += loss.item()
            steps += 1

        scheduler.step()
        avg_loss = epoch_loss / steps

        if epoch % 10 == 0 or epoch == 1:
            print(f"==> Epoch {epoch:03d}/{epochs} | Avg Loss: {avg_loss:.4f} | "
                  f"LR: {optimizer.param_groups[0]['lr']:.6f}")

        if avg_loss < best_loss:
            best_loss = avg_loss
            best_epoch = epoch
            torch.save(model.state_dict(), "baseline_best.pt")

    torch.save(model.state_dict(), "baseline_final.pt")
    print(f"\n{'='*55}")
    print(f"Baseline 训练完成！")
    print(f"  最优 Epoch : {best_epoch}  |  Best Loss: {best_loss:.4f}")
    print(f"  最优权重   : baseline_best.pt")
    print(f"  最终权重   : baseline_final.pt")
    print(f"{'='*55}")
    print(f"\n下一步: python generate_baseline.py")


if __name__ == "__main__":
    train_baseline()
