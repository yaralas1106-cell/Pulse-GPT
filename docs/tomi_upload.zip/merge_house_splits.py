"""
House 分轨合并器 (v1.0)
========================
将 House004-009 的分轨 MIDI（Kick, Snare, Hihat, Bass, Chords, Lead）
按照"同一首歌 + 同一段落"的逻辑合并为完整多轨 MIDI。

每首歌每个段落（Intro / Drop / Breakdown / Outro）生成一个合并文件，
包含 DRUMS (kick+snare+clap+hihat) + BASS + CHORD + MELODY 四轨。

输出文件命名格式：
  HOUSE_{songID}_{STRUCT}_{BPM}.mid
  例: HOUSE_House007_DROP_124.mid
"""

import os
import glob
import re
import pretty_midi
from collections import defaultdict

SOURCE_ROOT = r"d:\BigData\PycharmProject\Dynamic-Music-Transformer\data"
RAW_DIR = r"d:\BigData\PycharmProject\TOMI-GPT\dataset\raw"

# ──────────────────────────────────────────────
# 工具函数
# ──────────────────────────────────────────────

def get_track_type(filename):
    """从分轨文件名推断轨道类型"""
    f = filename.lower()
    # 鼓组类
    if any(k in f for k in ['kick', 'snare', 'clap', 'hihat', 'hihats', 'closedhh',
                              'openhh', 'drum', 'perc', 'rim', 'crash']):
        return 'DRUMS'
    # 贝斯
    if any(k in f for k in ['bass', '808', 'sub']):
        return 'BASS'
    # 和弦
    if any(k in f for k in ['chord', 'chords', 'pad', 'piano', 'keys', 'stab', 'org', 'arp']):
        return 'CHORD'
    # 旋律
    if any(k in f for k in ['lead', 'melody', 'synth', 'vox']):
        return 'MELODY'
    return None  # 无法识别，跳过

def extract_section(filename):
    """从文件名提取段落标签"""
    f = filename.upper()
    if 'BREAKDOWN' in f or 'BREAK' in f: return 'BREAKDOWN'
    if 'BUILDUP' in f or 'BUILD' in f:   return 'BUILDUP'
    if 'DROP2' in f:                      return 'DROP2'
    if 'DROP' in f:                       return 'DROP'
    if 'INTRO' in f:                      return 'INTRO'
    if 'OUTRO' in f:                      return 'OUTRO'
    return 'PATTERN'

def extract_bpm(filename, folder=''):
    """提取 BPM"""
    m = re.search(r'_(\d{3})\.mid', filename)
    if m and 80 <= int(m.group(1)) <= 200:
        return int(m.group(1))
    m = re.search(r'_(1[2-4]\d)_', filename + '_')
    if m:
        return int(m.group(1))
    return 128

# ──────────────────────────────────────────────
# 主逻辑：按歌、按段落分组合并
# ──────────────────────────────────────────────

def merge_house_splits():
    os.makedirs(RAW_DIR, exist_ok=True)

    # 清理旧的 HOUSE 合并文件（保留手动建立的分段文件）
    old_house = glob.glob(os.path.join(RAW_DIR, "HOUSE_House0*.mid"))
    for f in old_house:
        os.remove(f)
    print(f"已清理 {len(old_house)} 个旧文件")

    houses = ['House004', 'House005', 'House006', 'House007', 'House008', 'House009']
    total = 0

    for house in houses:
        folder = os.path.join(SOURCE_ROOT, house)
        if not os.path.isdir(folder):
            continue

        all_files = glob.glob(os.path.join(folder, '*.mid'))

        # 按段落分组: { 'DROP': [(path, track_type), ...], 'INTRO': [...], ... }
        section_groups = defaultdict(list)

        for fpath in all_files:
            fname = os.path.basename(fpath)
            t_type = get_track_type(fname)
            if t_type is None:
                continue
            section = extract_section(fname)
            section_groups[section].append((fpath, t_type))

        bpm_hint = extract_bpm(all_files[0] if all_files else '', house)

        for section, pairs in section_groups.items():
            if not pairs:
                continue

            # 统计有哪些轨道类型
            types_present = set(t for _, t in pairs)

            # 只要有超过1种轨道类型，我们认为这是有价值的多轨样本
            # 鼓轨是必须的（否则这个问题就没解决）
            if 'DRUMS' not in types_present and len(types_present) < 2:
                print(f"  [SKIP] {house} {section} — 只有单轨且无鼓：{types_present}")
                continue

            # 合并
            combined = pretty_midi.PrettyMIDI(initial_tempo=bpm_hint)
            has_notes = False

            # 按轨道类型顺序合并（DRUMS→BASS→CHORD→MELODY）
            order = ['DRUMS', 'BASS', 'CHORD', 'MELODY']
            ordered_pairs = sorted(pairs, key=lambda x: order.index(x[1]) if x[1] in order else 99)

            for fpath, t_type in ordered_pairs:
                try:
                    pm = pretty_midi.PrettyMIDI(fpath)
                    for inst in pm.instruments:
                        new_inst = pretty_midi.Instrument(
                            program=inst.program,
                            is_drum=(t_type == 'DRUMS'),
                            name=t_type
                        )
                        new_inst.notes = inst.notes
                        if inst.notes:
                            has_notes = True
                        combined.instruments.append(new_inst)
                except Exception as e:
                    print(f"    [WARN] {os.path.basename(fpath)}: {e}")

            if not has_notes:
                continue

            # 段落编号（Drop/Drop2 → section 1/2）
            sec_num = 2 if '2' in section else 1
            struct_base = section.rstrip('2')  # DROP2 → DROP

            out_name = f"HOUSE_{house}_{struct_base}{sec_num}_{bpm_hint}.mid"
            out_path = os.path.join(RAW_DIR, out_name)
            combined.write(out_path)

            n_tracks = len(types_present)
            print(f"  [OK] {out_name}  ({n_tracks} 轨: {sorted(types_present)})")
            total += 1

    print(f"\n[DONE] 生成了 {total} 个 House 多轨合并样本")
    return total

if __name__ == "__main__":
    merge_house_splits()
