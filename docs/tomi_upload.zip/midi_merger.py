import os
import pretty_midi
import copy

def merge_ableton_stems(stem_files, output_path):
    print(f"Merging {len(stem_files)} files into {output_path}...")
    
    # Create a completely new empty MIDI object
    merged_midi = pretty_midi.PrettyMIDI()
    
    # Create the unified Drums track (Channel 10 in standard MIDI, is_drum=True in pretty_midi)
    unified_drums = pretty_midi.Instrument(program=0, is_drum=True, name="Drums")
    
    for file_path in stem_files:
        if not os.path.exists(file_path):
            print(f"Warning: File not found {file_path}")
            continue
            
        print(f" Loading: {os.path.basename(file_path)}")
        pm = pretty_midi.PrettyMIDI(file_path)
        
        # We need to figure out what type of stem this is based on its filename
        filename_lower = os.path.basename(file_path).lower()
        
        is_drum_part = ('kick' in filename_lower or 
                       'snare' in filename_lower or 
                       'hihat' in filename_lower or 
                       'drum' in filename_lower or
                       'clap' in filename_lower or
                       'perc' in filename_lower)
                       
        if is_drum_part:
            # Shift all notes from this drum stem into the unified_drums track
            # Auto-map based on filename to save user from GM mapping headaches
            target_pitch = 35 # Default fallback
            if 'kick' in filename_lower:
                target_pitch = 36 # C1
            elif 'snare' in filename_lower:
                target_pitch = 38 # D1
            elif 'clap' in filename_lower:
                target_pitch = 39 # D#1 Hand Clap
            elif 'hihat' in filename_lower or 'hat' in filename_lower:
                target_pitch = 42 # F#1
                
            for inst in pm.instruments:
                for note in inst.notes:
                    new_note = copy.deepcopy(note)
                    new_note.pitch = target_pitch
                    unified_drums.notes.append(new_note)
        else:
            # It's a non-drum track (like Bass, Chord, Melody)
            # Create a dedicated track for it in the merged MIDI
            # Fallback program 0 if it wasn't set, but try to respect the original if it exists
            prog = 0
            if pm.instruments:
                prog = pm.instruments[0].program
                
            # Determine a good name based on the filename to help dataset_processor.py
            track_name = "Melody"
            if 'bass' in filename_lower or '808' in filename_lower:
                track_name = "Bass"
            elif 'chord' in filename_lower or 'pad' in filename_lower or 'stab' in filename_lower or 'arp' in filename_lower:
                track_name = "Chord"
                
            new_inst = pretty_midi.Instrument(program=prog, is_drum=False, name=track_name)
            
            for inst in pm.instruments:
                for note in inst.notes:
                    new_inst.notes.append(note)
                    
            merged_midi.instruments.append(new_inst)
            
    # Finally, append the unified drums if it has notes
    if len(unified_drums.notes) > 0:
        # Sort notes by start time just to be clean
        unified_drums.notes.sort(key=lambda x: x.start)
        merged_midi.instruments.append(unified_drums)
        
    # Write to disk
    merged_midi.write(output_path)
    print(f"Merge Complete! Saved to: {output_path}")

if __name__ == "__main__":
    # The five files requested by the user for Break section
    # The four files requested by the user for Outro section
    files_to_merge = [
        r"d:\BigData\PycharmProject\Dynamic-Music-Transformer\data\House003\House003_Bass_Outro.mid",
        r"d:\BigData\PycharmProject\Dynamic-Music-Transformer\data\House003\House003_Clap_Outro.mid",
        r"d:\BigData\PycharmProject\Dynamic-Music-Transformer\data\House003\House003_Hihat_Outro.mid",
        r"d:\BigData\PycharmProject\Dynamic-Music-Transformer\data\House003\House003_Kick_Outro.mid"
    ]
    
    out_file = r"d:\BigData\PycharmProject\Dynamic-Music-Transformer\data\House003\House003_Outro_128.mid"
    merge_ableton_stems(files_to_merge, out_file)

