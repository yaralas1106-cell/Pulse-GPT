import pretty_midi
import math
import numpy as np
import pandas as pd
from sklearn.cluster import KMeans
from sklearn.preprocessing import KBinsDiscretizer

class MIDIEnergyProcessor:
    def __init__(self, midi_path: str):
        self.midi_path = midi_path
        try:
            self.midi_data = pretty_midi.PrettyMIDI(midi_path)
        except Exception as e:
            print(f"Error loading MIDI {midi_path}: {e}")
            self.midi_data = None
            
        # Params for energy formula: D_t = alpha * density + beta * mean_vel + gamma * kick_count
        self.alpha = 0.35 # Density
        self.beta = 0.35  # Velocity
        self.gamma = 0.20 # Kick
        self.delta = 0.10 # Pitch height
        
    def _is_drum_track(self, instrument: pretty_midi.Instrument) -> bool:
        name = instrument.name.lower().strip()
        if 'drum' in name or 'perc' in name or 'kick' in name:
            return True
        return instrument.is_drum
        
    def _is_bass_track(self, instrument: pretty_midi.Instrument) -> bool:
        name = instrument.name.lower().strip()
        if 'bass' in name or '808' in name:
            return True
        # Standard General MIDI bass range is roughly 32-39
        return 32 <= instrument.program <= 39 and not instrument.is_drum
        
    def _is_melody_track(self, instrument: pretty_midi.Instrument) -> bool:
        name = instrument.name.lower().strip()
        if 'melody' in name or 'lead' in name or 'chord' in name or 'pad' in name or 'synth' in name:
            return True
        # Exclude drums, bass
        if self._is_drum_track(instrument) or self._is_bass_track(instrument):
            return False
        return True

    def get_bar_boundaries(self) -> list:
        """Calculate start and end times for each bar based on tempo and time signature."""
        if not self.midi_data: return []
        
        # Assumption: 4/4 time signature for typical EDM
        # If time_signature_changes is empty, default to 4/4
        beats = self.midi_data.get_beats()
        bars = []
        for i in range(0, len(beats)-4, 4):
            bar_start = beats[i]
            bar_end = beats[i+4]
            bars.append((bar_start, bar_end))
        return bars

    def extract_bar_features(self, start_time: float, end_time: float):
        notes_in_bar = []
        drum_notes = []
        
        for inst in self.midi_data.instruments:
            for note in inst.notes:
                if note.start >= start_time and note.start < end_time:
                    notes_in_bar.append(note)
                    if inst.is_drum:
                        drum_notes.append(note)
                        
        # 1. Note Density (normalized roughly)
        density = len(notes_in_bar)
        
        # 2. Mean Velocity & 3. Mean Pitch (Excluding drums for pitch)
        if len(notes_in_bar) > 0:
            mean_vel = np.mean([n.velocity for n in notes_in_bar]) / 127.0
            
            # Compute mean pitch only for non-drum instruments giving musical frequency energy
            melodic_notes = [n.pitch for n in notes_in_bar if n not in drum_notes]
            mean_pitch = np.mean(melodic_notes) / 127.0 if len(melodic_notes) > 0 else 0.0
        else:
            mean_vel = 0.0
            mean_pitch = 0.0
            
        # 4. Kick detection (Kick is typically pitch 35 or 36 in GM)
        kick_count = sum(1 for dn in drum_notes if dn.pitch in [35, 36])
        
        return density, mean_vel, kick_count, mean_pitch

    def process_song_dynamic_curve(self):
        """Processes the whole song to obtain D_t sequence"""
        if not self.midi_data: return None
        
        bars = self.get_bar_boundaries()
        features = []
        for idx, (start, end) in enumerate(bars):
            density, mean_vel, kick_count, mean_pitch = self.extract_bar_features(start, end)
            features.append({
                'bar_index': idx,
                'density': density,
                'velocity': mean_vel,
                'kick_count': kick_count,
                'pitch': mean_pitch
            })
            
        df = pd.DataFrame(features)
        if df.empty:
            return df
            
        # Use absolute global max thresholds instead of relative max per clip.
        # This fixes the issue where a quiet 'Intro' clip has its own peak normalized to max Level 8.
        # Density: 40 notes per bar is a packed EDM bar. Kick: 8 kicks per bar is dense.
        GLOBAL_MAX_DENSITY = 40.0
        GLOBAL_MAX_KICK = 8.0
        
        df['norm_density'] = np.clip(df['density'] / GLOBAL_MAX_DENSITY, 0.0, 1.0)
        df['norm_kick'] = np.clip(df['kick_count'] / GLOBAL_MAX_KICK, 0.0, 1.0)
        
        # Calculate D_t with Pitch
        df['D_t'] = (self.alpha * df['norm_density'] + 
                     self.beta * df['velocity'] + 
                     self.gamma * df['norm_kick'] +
                     self.delta * df['pitch'])
        
        return df

    def discretize_energy(self, df: pd.DataFrame, num_levels=8) -> pd.DataFrame:
        """
        Calculates distinct energy levels using K-Bins Discretizer or KMeans.
        Level 1 to Level 8 depending on the num_levels.
        """
        if df is None or df.empty or 'D_t' not in df.columns:
            return df
            
        # We use KBinsDiscretizer with strategy='kmeans' for 1D data to find natural breaks
        # or 'quantile' to guarantee equal representation across levels.
        # Electronic music energy tends to be polarized, so a quantile approach might give more balanced data
        # but kmeans preserves the distinct structural leaps (like Drop vs Build-up).
        
        # We need at least num_levels distinct data points to cluster, handle edge cases
        dt_values = df[['D_t']].values
        n_samples = len(dt_values)
        
        if n_samples < num_levels:
            # Fallback if the song is too short
            discretizer = KBinsDiscretizer(n_bins=n_samples, encode='ordinal', strategy='uniform')
        else:
            discretizer = KBinsDiscretizer(n_bins=num_levels, encode='ordinal', strategy='kmeans')
            
        # Add 1 so levels are 1-based (Level_1 ... Level_8)
        df['Energy_Level'] = discretizer.fit_transform(dt_values).astype(int) + 1
        
        return df

if __name__ == "__main__":
    import os
    print("MIDI Energy Processor initialized. Ready to process EDM MIDIs for Dynamic curves.")
