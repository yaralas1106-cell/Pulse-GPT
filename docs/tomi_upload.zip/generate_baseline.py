"""
PulseGPT — generate_baseline.py
=================================
使用 Baseline（无控制标签）模型生成 MIDI。
对比用：与 generate.py（PulseGPT 有控制）生成的结果一起送入 evaluate.py。

Baseline 生成策略：
  - 不给任何控制 Token 作为 Prompt
  - 只从 <BOS> + [BAR_START] 开始，让模型自由发挥
  - 生成相同数量的小节

用法:
  python generate_baseline.py
  python generate_baseline.py --bars 8 --temperature 0.9 --output baseline_out.mid
"""

import torch
import torch.nn.functional as F
import pretty_midi
import argparse
import os

from tokenizer import PulseTokenizer
from model import PulseLlamaModel


class BaselineGenerator:
    def __init__(self, model_path="baseline_best.pt",
                 vocab_path="dataset/processed/pulse_vocab.json"):
        self.tokenizer = PulseTokenizer(vocab_path)
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

        self.model = PulseLlamaModel(
            vocab_size=len(self.tokenizer),
            pad_token_id=self.tokenizer.pad_id
        )

        if os.path.exists(model_path):
            self.model.load_state_dict(
                torch.load(model_path, map_location=self.device)
            )
            print(f"[Baseline] 模型权重加载: {model_path}")
        else:
            print(f"[WARN] 未找到 {model_path}，使用随机权重（请先运行 train_baseline.py）")

        self.model.to(self.device)
        self.model.eval()

    @torch.no_grad()
    def generate(self, max_new_tokens=512, temperature=0.85, top_k=50):
        """
        无条件生成：只从 <BOS> 开始，不输入任何控制 Token
        这是 Baseline 的核心特征
        """
        bos_id = self.tokenizer.bos_id
        bar_start_id = self.tokenizer.t2i.get("[BAR_START]", None)

        # 最简 Prompt：<BOS> [BAR_START]
        if bar_start_id is not None:
            input_ids = torch.tensor([[bos_id, bar_start_id]], dtype=torch.long).to(self.device)
        else:
            input_ids = torch.tensor([[bos_id]], dtype=torch.long).to(self.device)

        print(f"[Baseline] 无控制生成（无 GENRE/STRUCT/ENERGY 标签）")
        print(f"[Baseline] Prompt: {[self.tokenizer.i2t.get(i, '?') for i in input_ids[0].tolist()]}")

        generated = input_ids[0].tolist()

        for _ in range(max_new_tokens):
            x = torch.tensor([generated[-512:]], dtype=torch.long).to(self.device)
            _, logits = self.model(x, attention_mask=None, labels=None)
            logits = logits[0, -1, :]

            # Temperature + Top-K 采样
            logits = logits / temperature
            if top_k > 0:
                top_vals, _ = torch.topk(logits, top_k)
                logits[logits < top_vals[-1]] = float('-inf')

            probs = F.softmax(logits, dim=-1)
            next_id = torch.multinomial(probs, num_samples=1).item()

            generated.append(next_id)

            # 遇到 EOS 停止
            if next_id == self.tokenizer.eos_id:
                break

        tokens = [self.tokenizer.i2t.get(i, '<UNK>') for i in generated]
        return tokens

    def tokens_to_midi(self, tokens, output_path="baseline_output.mid", bpm=128):
        """将 Token 序列转换为 MIDI 文件（与 generate.py 相同的解码器）"""
        pm = pretty_midi.PrettyMIDI(initial_tempo=bpm)

        beat_dur = 60.0 / bpm
        bar_dur  = beat_dur * 4

        PITCH_NAMES = ["C","C#","D","D#","E","F","F#","G","G#","A","A#","B"]
        def name_to_pitch(note_name):
            try:
                pc   = PITCH_NAMES.index(note_name[:-1])
                oct_ = int(note_name[-1])
                return (oct_ + 1) * 12 + pc
            except:
                return 60

        instruments = {}
        TRACK_PROGRAMS = {
            'BASS':   32,
            'CHORD':  0,
            'MELODY': 80,
            'DRUMS':  0,
        }

        current_track = None
        current_bar   = 0
        bar_start_t   = 0.0

        i = 0
        while i < len(tokens):
            tok = tokens[i]

            if tok == '[BAR_START]':
                bar_start_t = current_bar * bar_dur
            elif tok == '[BAR_END]':
                current_bar += 1
            elif tok.startswith('[TRACK_') and not tok.endswith('_END]') and tok != '[TRACK_DRUMS]':
                tname = tok[7:-1]  # e.g. BASS
                current_track = tname
                if tname not in instruments:
                    is_drum = (tname == 'DRUMS')
                    inst = pretty_midi.Instrument(
                        program=TRACK_PROGRAMS.get(tname, 0),
                        is_drum=is_drum,
                        name=tname
                    )
                    instruments[tname] = inst
            elif tok == '[TRACK_DRUMS]':
                current_track = 'DRUMS'
                if 'DRUMS' not in instruments:
                    instruments['DRUMS'] = pretty_midi.Instrument(
                        program=0, is_drum=True, name='DRUMS'
                    )
            elif tok.endswith('_END]'):
                current_track = None
            elif tok.startswith('N:') and current_track:
                # N:TRACK:NOTE:pPOS:dDUR:vVEL
                parts = tok.split(':')
                if len(parts) >= 6:
                    try:
                        note_name = parts[2]
                        pos_step  = int(parts[3][1:])
                        dur_step  = int(parts[4][1:])
                        vel_bin   = int(parts[5][1:])
                        pitch     = name_to_pitch(note_name)
                        vel       = max(20, int(vel_bin / 7.0 * 127))
                        step_dur  = bar_dur / 16.0
                        start_t   = bar_start_t + pos_step * step_dur
                        end_t     = start_t + max(step_dur, dur_step * step_dur)
                        note = pretty_midi.Note(velocity=vel, pitch=pitch,
                                                start=start_t, end=end_t)
                        instruments[current_track].notes.append(note)
                    except:
                        pass
            elif tok.startswith('D:') and current_track == 'DRUMS':
                # D:DRUM_NAME:pPOS:dDUR:vVEL
                GM_DRUMS = {
                    'KICK': 36, 'KICK2': 35, 'SNARE': 38, 'SNARE2': 40,
                    'HIHAT_CLOSED': 42, 'HIHAT_OPEN': 46, 'HIHAT_PEDAL': 44,
                    'CLAP': 39, 'RIMSHOT': 37, 'CRASH': 49, 'RIDE': 51,
                }
                parts = tok.split(':')
                if len(parts) >= 5:
                    try:
                        drum_name = parts[1]
                        pos_step  = int(parts[2][1:])
                        dur_step  = int(parts[3][1:])
                        vel_bin   = int(parts[4][1:])
                        pitch     = GM_DRUMS.get(drum_name, 36)
                        vel       = max(20, int(vel_bin / 7.0 * 127))
                        step_dur  = bar_dur / 16.0
                        start_t   = bar_start_t + pos_step * step_dur
                        end_t     = start_t + step_dur
                        note = pretty_midi.Note(velocity=vel, pitch=pitch,
                                                start=start_t, end=end_t)
                        if 'DRUMS' in instruments:
                            instruments['DRUMS'].notes.append(note)
                    except:
                        pass
            i += 1

        for inst in instruments.values():
            if inst.notes:
                pm.instruments.append(inst)

        if pm.instruments:
            pm.write(output_path)
            print(f"[Baseline] MIDI 保存: {output_path}")
        else:
            print(f"[WARN] 生成内容为空，未保存文件")

        return pm


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='PulseGPT Baseline Generator')
    parser.add_argument('--model',       type=str,   default='baseline_best.pt')
    parser.add_argument('--output',      type=str,   default='baseline_output.mid')
    parser.add_argument('--bpm',         type=int,   default=128)
    parser.add_argument('--temperature', type=float, default=0.85)
    parser.add_argument('--max_tokens',  type=int,   default=512)
    args = parser.parse_args()

    gen = BaselineGenerator(model_path=args.model)
    tokens = gen.generate(
        max_new_tokens=args.max_tokens,
        temperature=args.temperature
    )

    # 预览生成内容（检查有无轨道结构）
    track_tokens = [t for t in tokens if t.startswith('[TRACK_')]
    print(f"\n预览 - 检测到的轨道 Token: {track_tokens[:10]}")
    print(f"总 Token 数: {len(tokens)}")

    gen.tokens_to_midi(tokens, output_path=args.output, bpm=args.bpm)
    print(f"\n[DONE] Baseline 生成完毕: {args.output}")
    print(f"下一步: python evaluate.py --file {args.output} --target_struct PATTERN --bpm {args.bpm}")
