"""
batch_process.py
────────────────────────────────────────────────────────────────
自动批处理脚本：
  1. 扫描指定文件夹中所有 MIDI stem 文件
  2. 按照 Genre + SongID + Struct 自动分组
  3. 调用 merge_ableton_stems 合并每个分组
  4. 将合并结果复制到 dataset/raw/ 目录
  5. 调用 build_pulse_dataset.py 更新 JSONL 数据集

用法:
  python batch_process.py --input_dir "path/to/folder" --bpm 128
  python batch_process.py --input_dir "path/to/folder"  # BPM 默认 128
────────────────────────────────────────────────────────────────
"""

import os
import re
import sys
import shutil
import argparse
from collections import defaultdict

# ── 导入合并函数 ──────────────────────────────────────────────
sys.path.insert(0, os.path.dirname(__file__))
from midi_merger import merge_ableton_stems

# ── 常量路径 ──────────────────────────────────────────────────
RAW_DIR   = os.path.join(os.path.dirname(__file__), "dataset", "raw")
BUILD_SCRIPT = os.path.join(os.path.dirname(__file__), "build_pulse_dataset.py")

# ── 段落关键字识别（顺序敏感，优先匹配更长的词）──────────────
STRUCT_KEYWORDS = [
    "breakdown2", "breakdown", "break2", "break",
    "buildup2", "buildup", "build2", "build",
    "drop2", "drop",
    "outro2", "outro",
    "intro2", "intro",
    "verse2", "verse",
    "chorus2", "chorus",
    "bridge2", "bridge",
]

def detect_struct(filename_lower: str) -> str:
    """从文件名中提取段落标签。支持 Drop2, Breakdown2 等编号段落。"""
    for kw in STRUCT_KEYWORDS:
        if kw in filename_lower:
            # 统一别名映射
            alias_map = {
                "break": "Breakdown",
                "break2": "Breakdown2",
                "build": "Buildup",
                "build2": "Buildup2",
                "buildup": "Buildup",
                "buildup2": "Buildup2",
            }
            return alias_map.get(kw, kw.capitalize())
    return "Unknown"

def detect_song_id(filename: str) -> str:
    """
    尝试从文件名解析 SongID（如 House004）。
    规则：找第一个大写字母开头、后跟数字的词组。
    """
    # 例: House004_Bass_Drop.mid -> House004
    m = re.match(r"([A-Za-z]+\d+)", os.path.basename(filename))
    if m:
        return m.group(1)
    # fallback: 用文件名头部
    return os.path.basename(filename).split("_")[0]

def group_stems(midi_files: list) -> dict:
    """
    将文件列表按 (SongID, Struct) 分组。
    返回:  { (song_id, struct): [file1, file2, ...] }
    """
    groups = defaultdict(list)
    for f in midi_files:
        fn_lower = os.path.basename(f).lower()
        song_id  = detect_song_id(f)
        struct   = detect_struct(fn_lower)
        groups[(song_id, struct)].append(f)
    return groups

def infer_bpm_from_filename(filename: str, default_bpm: int) -> int:
    """尝试从文件名中找到 BPM 数字，如 House004_128_Drop.mid → 128。"""
    m = re.search(r'_(\d{2,3})_', os.path.basename(filename))
    if m:
        return int(m.group(1))
    return default_bpm

def main():
    parser = argparse.ArgumentParser(description="批量合并 MIDI Stem 并更新训练集")
    parser.add_argument("--input_dir", required=True,
                        help="包含 MIDI stem 文件的文件夹路径")
    parser.add_argument("--bpm", type=int, default=128,
                        help="BPM（默认 128）")
    parser.add_argument("--no_rebuild", action="store_true",
                        help="仅合并，不重新构建 JSONL 数据集")
    args = parser.parse_args()

    input_dir = args.input_dir
    if not os.path.isdir(input_dir):
        print(f"[ERROR] 目录不存在: {input_dir}")
        sys.exit(1)

    # ── 1. 扫描所有 MIDI 文件 ─────────────────────────────────
    midi_files = []
    for root, _, files in os.walk(input_dir):
        for f in files:
            if f.lower().endswith(".mid") or f.lower().endswith(".midi"):
                midi_files.append(os.path.join(root, f))

    if not midi_files:
        print(f"[WARN] 在 {input_dir} 中未找到任何 MIDI 文件！")
        sys.exit(0)

    print(f"\n找到 {len(midi_files)} 个 MIDI 文件，开始分组...\n")

    # ── 2. 分组 ───────────────────────────────────────────────
    groups = group_stems(midi_files)

    print(f"共识别出 {len(groups)} 个段落分组：")
    for (song_id, struct), files in sorted(groups.items()):
        print(f"  [{song_id} | {struct}] → {len(files)} 轨: "
              f"{[os.path.basename(f) for f in files]}")

    print()

    # ── 3. 逐组合并 ───────────────────────────────────────────
    os.makedirs(RAW_DIR, exist_ok=True)
    merged_count = 0

    for (song_id, struct), stem_files in sorted(groups.items()):
        # 推断 BPM
        bpm = infer_bpm_from_filename(stem_files[0], args.bpm)

        # 输出文件名格式: House004_Drop_128.mid
        out_name = f"{song_id}_{struct}_{bpm}.mid"
        out_path = os.path.join(RAW_DIR, out_name)

        if os.path.exists(out_path):
            print(f"[SKIP] 已存在: {out_name}")
            continue

        print(f"[MERGE] {song_id} / {struct} ({len(stem_files)} 轨) → {out_name}")
        try:
            merge_ableton_stems(stem_files, out_path)
            merged_count += 1
        except Exception as e:
            print(f"  [ERROR] 合并失败: {e}")

    print(f"\n合并完成！共新增 {merged_count} 个文件到 dataset/raw/\n")

    # ── 4. 重新构建 JSONL 数据集 ──────────────────────────────
    if not args.no_rebuild and merged_count > 0:
        print("=" * 50)
        print("开始重新构建 JSONL 数据集...")
        import subprocess
        result = subprocess.run(
            [sys.executable, BUILD_SCRIPT],
            cwd=os.path.dirname(__file__)
        )
        if result.returncode != 0:
            print("[ERROR] 数据集构建失败！请检查 build_pulse_dataset.py")
        else:
            print("[DONE] 数据集已更新！")
    elif not args.no_rebuild:
        print("[INFO] 没有新文件，跳过数据集重建。")


if __name__ == "__main__":
    main()
