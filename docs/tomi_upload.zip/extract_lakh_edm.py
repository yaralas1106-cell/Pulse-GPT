"""
PulseGPT — extract_lakh_edm.py
================================
从 Lakh MIDI Dataset 中自动筛选 EDM 风格的 MIDI 文件，
进行智能分轨分类、分段、命名，输出为 PulseGPT 训练格式。

流程：
  1. 遍历已知 EDM 艺术家文件夹
  2. 分析每个 MIDI：BPM、轨道数、时长
  3. 自动分轨分类（Drums/Bass/Chord/Melody）
  4. 输出为标准命名格式
"""

import os
import glob
import re
import pretty_midi
import numpy as np
from collections import defaultdict

RAW_DIR = r"d:\BigData\PycharmProject\TOMI-GPT\dataset\raw"

# ──────────────────────────────────────────────────────────────────────
# 1. EDM 艺术家白名单（从 Lakh 目录中筛选）
# ──────────────────────────────────────────────────────────────────────

EDM_ARTISTS = {
    # Techno / Electronic
    '808_State':        'TECHNO',
    'Kraftwerk':        'TECHNO',
    'Orbital':          'TECHNO',
    'Technotronic':     'TECHNO',
    'Technohead':       'TECHNO',
    'Darude':           'TRANCE',
    'The_Prodigy':      'BREAKS',
    'The_KLF':          'TECHNO',
    'Scooter':          'HARDSTYLE',
    'Marusha':          'TECHNO',

    # House / Dance
    'Daft_Punk':        'HOUSE',
    'Fatboy_Slim':      'HOUSE',
    'Faithless':        'HOUSE',
    'Moby':             'HOUSE',
    'New_Order':        'SYNTHPOP',
    'Depeche_Mode':     'SYNTHPOP',
    'Pet_Shop_Boys':    'SYNTHPOP',
    'Erasure':          'SYNTHPOP',
    'La_Bouche':        'EURODANCE',
    'Corona':           'EURODANCE',
    'Real_McCoy':       'EURODANCE',
    'Haddaway':         'EURODANCE',
    '2_Unlimited':      'EURODANCE',
    'Snap':             'EURODANCE',
    'Culture_Beat':     'EURODANCE',
    'Eiffel_65':        'EURODANCE',
    'Masterboy':        'EURODANCE',
    'DJ_BoBo':          'EURODANCE',
    'Captain_Jack':     'EURODANCE',
    'Fun_Factory':      'EURODANCE',
    'Mr._President':    'EURODANCE',
    'Vengaboys':        'EURODANCE',
    'Aqua':             'EURODANCE',

    # Trance
    'Robert_Miles':     'TRANCE',
    'Energy_52':        'TRANCE',
    'Dance_2_Trance':   'TRANCE',
    'DJ_Quicksilver':   'TRANCE',
    'Jam_and_Spoon':    'TRANCE',
    'RMB':              'TRANCE',
    'SASH_':            'TRANCE',
    'Enigma':           'AMBIENT',

    # Ambient / Downtempo
    'Enya':             'AMBIENT',

    # Disco / Funk (高能量，有价值)
    'Donna_Summer':     'DISCO',
    'Summer_Donna':     'DISCO',
    'Gloria_Gaynor':    'DISCO',
    'Village_People':   'DISCO',
    'Boney_M':          'DISCO',
    'KC_and_The_Sunshine_Band': 'DISCO',
    'Bee_Gees':         'DISCO',
    'Earth,_Wind_and_Fire': 'DISCO',
    'Chic':             'DISCO',
    'Kool_and_The_Gang': 'DISCO',
    'Gloria_Estefan':   'DISCO',
    'Estefan_Gloria':   'DISCO',

    # Electronic Pop
    'Madonna':          'ELECTROPOP',
    'Kylie_Minogue':    'ELECTROPOP',
    'Britney_Spears':   'ELECTROPOP',
    'Christina_Aguilera':'ELECTROPOP',
    'Janet_Jackson':    'ELECTROPOP',
    'Robbie_Williams':  'ELECTROPOP',

    # Industrial / EBM
    'Nine_Inch_Nails':  'INDUSTRIAL',
    'Rammstein':        'INDUSTRIAL',

    # Misc EDM-adjacent
    'Jamiroquai':       'FUNK',
    'Adamski':          'HOUSE',
    'Inner_City':       'HOUSE',
    'Black_Box':        'HOUSE',
    'Robin_S':          'HOUSE',
    'Crystal_Waters':   'HOUSE',
    'C+C_Music_Factory':'HOUSE',
    'Bobby_Brown':      'RNB',
    'Michael_Jackson':  'POP',
    'Jackson_Michael':  'POP',
}

# ──────────────────────────────────────────────────────────────────────
# 2. MIDI 分析与分轨
# ──────────────────────────────────────────────────────────────────────

def estimate_bpm(pm):
    """估算 MIDI 的 BPM"""
    try:
        tempos = pm.get_tempo_changes()[1]
        if len(tempos) > 0:
            bpm = int(round(np.median(tempos)))
            if 60 <= bpm <= 200:
                return bpm
    except:
        pass
    return 120

def classify_instrument(inst):
    """根据 MIDI 乐器信息分类轨道"""
    if inst.is_drum:
        return 'DRUMS'

    name = inst.name.upper() if inst.name else ''
    prog = inst.program

    # 按名称
    if any(k in name for k in ['BASS', '808', 'SUB']):
        return 'BASS'
    if any(k in name for k in ['LEAD', 'MELODY', 'SYNTH LEAD', 'SOLO']):
        return 'MELODY'
    if any(k in name for k in ['PAD', 'CHORD', 'STRINGS', 'ORGAN', 'PIANO', 'KEYS']):
        return 'CHORD'

    # 按 GM Program Number
    if 32 <= prog <= 39:   # Bass
        return 'BASS'
    if 0 <= prog <= 7:     # Piano
        return 'CHORD'
    if 24 <= prog <= 31:   # Guitar
        return 'CHORD'
    if 48 <= prog <= 63:   # Strings / Ensemble
        return 'CHORD'
    if 80 <= prog <= 87:   # Synth Lead
        return 'MELODY'
    if 88 <= prog <= 95:   # Synth Pad
        return 'CHORD'

    # 按音高范围推断
    if inst.notes:
        pitches = [n.pitch for n in inst.notes]
        avg_pitch = np.mean(pitches)
        if avg_pitch < 48:  # 低于 C3
            return 'BASS'
        elif avg_pitch > 72:  # 高于 C5
            return 'MELODY'

    return 'CHORD'  # 默认

def detect_key(pm):
    """简单调性检测：统计所有音符的 pitch class，最多的作为主音"""
    NOTE_NAMES = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B']
    pitch_hist = np.zeros(12)
    for inst in pm.instruments:
        if inst.is_drum:
            continue
        for note in inst.notes:
            pitch_hist[note.pitch % 12] += 1
    if pitch_hist.sum() == 0:
        return 'C', 'MINOR'
    root = int(np.argmax(pitch_hist))

    # 简单大小调判断：检查 root+3（小三度）vs root+4（大三度）
    minor_third = pitch_hist[(root + 3) % 12]
    major_third = pitch_hist[(root + 4) % 12]
    mode = 'MINOR' if minor_third > major_third else 'MAJOR'
    return NOTE_NAMES[root], mode


def process_midi_file(midi_path, artist_name, genre, output_dir, counter):
    """处理单个 MIDI 文件：分轨、分类、输出"""
    try:
        pm = pretty_midi.PrettyMIDI(midi_path)
    except Exception as e:
        return None

    # 过滤条件
    end_time = pm.get_end_time()
    if end_time < 10 or end_time > 600:  # 太短或太长
        return None

    total_notes = sum(len(inst.notes) for inst in pm.instruments)
    if total_notes < 20:  # 太少音符
        return None

    bpm = estimate_bpm(pm)
    root, mode = detect_key(pm)

    # 分轨分类
    track_map = defaultdict(list)  # {DRUMS: [inst1, inst2], BASS: [...], ...}
    for inst in pm.instruments:
        if not inst.notes:
            continue
        t_type = classify_instrument(inst)
        track_map[t_type].append(inst)

    # 至少要有2种轨道类型
    if len(track_map) < 2:
        return None

    # 构建合并后的 MIDI
    combined = pretty_midi.PrettyMIDI(initial_tempo=bpm)
    has_notes = False

    for t_type in ['DRUMS', 'BASS', 'CHORD', 'MELODY']:
        if t_type not in track_map:
            continue
        new_inst = pretty_midi.Instrument(
            program=0 if t_type == 'DRUMS' else track_map[t_type][0].program,
            is_drum=(t_type == 'DRUMS'),
            name=t_type
        )
        for orig_inst in track_map[t_type]:
            new_inst.notes.extend(orig_inst.notes)
            has_notes = True
        combined.instruments.append(new_inst)

    if not has_notes:
        return None

    # 生成文件名
    safe_artist = re.sub(r'[^A-Za-z0-9_]', '', artist_name)[:20]
    song_name = os.path.splitext(os.path.basename(midi_path))[0]
    safe_song = re.sub(r'[^A-Za-z0-9_]', '', song_name)[:30]

    out_name = f"LAKH_{genre}_{safe_artist}_{safe_song}_{counter:03d}_KEY{root}_{mode}_{bpm}.mid"
    out_path = os.path.join(output_dir, out_name)
    combined.write(out_path)

    types = sorted(track_map.keys())
    return {
        'file': out_name,
        'genre': genre,
        'bpm': bpm,
        'key': f"{root}_{mode}",
        'tracks': types,
        'n_notes': total_notes,
        'duration': round(end_time, 1),
    }


# ──────────────────────────────────────────────────────────────────────
# 3. 主流程
# ──────────────────────────────────────────────────────────────────────

def main():
    print(f"\n{'='*60}")
    print(f"  Lakh MIDI Dataset -> PulseGPT EDM Extractor")
    print(f"{'='*60}\n")

    output_dir = RAW_DIR
    total = 0
    genre_stats = defaultdict(int)
    track_stats = defaultdict(int)
    counter = 1

    for artist_dir, genre in sorted(EDM_ARTISTS.items()):
        artist_path = os.path.join(RAW_DIR, artist_dir)
        if not os.path.isdir(artist_path):
            continue

        midi_files = glob.glob(os.path.join(artist_path, '**', '*.mid'), recursive=True)
        if not midi_files:
            continue

        print(f"  [{genre:12s}] {artist_dir:30s} -> {len(midi_files)} MIDI files...", end=" ")
        artist_count = 0

        for mf in midi_files:
            result = process_midi_file(mf, artist_dir, genre, output_dir, counter)
            if result:
                artist_count += 1
                total += 1
                counter += 1
                genre_stats[genre] += 1
                for t in result['tracks']:
                    track_stats[t] += 1

        print(f"extracted {artist_count}")

    # 统计
    print(f"\n{'='*60}")
    print(f"  提取完成！共 {total} 个 EDM 多轨样本")
    print(f"{'='*60}")
    print(f"\n  按风格统计:")
    for g, c in sorted(genre_stats.items(), key=lambda x: -x[1]):
        print(f"    {g:15s}: {c:4d}")
    print(f"\n  按轨道类型统计（出现次数）:")
    for t, c in sorted(track_stats.items(), key=lambda x: -x[1]):
        print(f"    {t:10s}: {c:4d}")
    print(f"\n  下一步: python build_pulse_dataset.py")


if __name__ == "__main__":
    main()
