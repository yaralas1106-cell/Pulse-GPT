"""
PulseGPT Dataset Builder
========================
将用户准备好的多轨 MIDI 文件，转化为带有
[GENRE] / [STRUCT] / [ENERGY_LEVEL] 控制 Token 的训练序列。

不依赖 PulseGPT 的 C++ 库。完全使用 pure Python 实现。

输出格式：一个 JSONL 文件，每行是一个 JSON 数组，代表一首歌（段落）
的完整 Token 序列。
"""

import os
import glob
import json
import re
import numpy as np
import pretty_midi
from tqdm import tqdm
import sys
sys.path.append(r'd:\BigData\PycharmProject\TOMI-GPT')
from dataset_processor import MIDIEnergyProcessor

# ──────────────────────────────────────────────
# 1. 文件名解析器
# ──────────────────────────────────────────────

# 基础段落名（不含数字后缀）
VALID_STRUCTS = ["INTRO", "BREAKDOWN", "BUILDUP", "DROP", "OUTRO", "VERSE", "CHORUS", "BRIDGE", "PATTERN"]
VALID_GENRES  = ["HOUSE", "TECHNO", "TRANCE", "DUBSTEP", "DRUM_AND_BASS", "EDM", "BIGROOM",
                 "EURODANCE", "INDUSTRIAL", "AMBIENT", "BREAKS", "HARDSTYLE"]

def parse_filename(path):
    """
    从文件名中提取 genre / struct / section_order / bpm。
    支持格式：Genre_SongID_Struct[N]_BPM.mid
    示例：House007_Drop2_124.mid → struct='DROP', section_order=2
    """
    import re
    stem = os.path.splitext(os.path.basename(path))[0].upper()
    parts = stem.split("_")

    genre         = "UNKNOWN"
    struct        = "UNKNOWN"
    section_order = 1          # 默认是第一次出现
    bpm           = None

    for p in parts:
        # 检测 genre
        for v in VALID_GENRES:
            if v in p:
                genre = v
                break
        # 检测 struct（支持 DROP、DROP2、DROP3 等格式）
        m = re.match(r'^(' + '|'.join(VALID_STRUCTS) + r')(\d*)$', p)
        if m:
            struct        = m.group(1)                            # 基础名 DROP
            section_order = int(m.group(2)) if m.group(2) else 1  # 后缀数字
        # 检测 BPM
        if p.isdigit() and 60 <= int(p) <= 220:
            bpm = int(p)

    return genre, struct, section_order, bpm

# ──────────────────────────────────────────────
# 1.5 调性检测 (Key Detection)
# ──────────────────────────────────────────────

def estimate_key(pm_data: pretty_midi.PrettyMIDI):
    """
    基于音高直方图估计调性
    """
    import numpy as np
    
    # Krumhansl-Schmuckler 调性权重
    MAJOR_PROFILE = [6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88]
    MINOR_PROFILE = [6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17]
    PITCH_CLASSES = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B']

    # 获取全曲音高直方图 (12维向量，代表 0-11 个音级出现的强度)
    histogram = pm_data.get_pitch_class_histogram()
    if np.sum(histogram) == 0:
        return "C_MAJOR" # 没音符默认

    def get_correlation(profile, hist):
        return np.corrcoef(profile, hist)[0, 1]

    best_corr = -1.0
    best_key = "C_MAJOR"

    for i in range(12):
        # 旋转权重向量来匹配 12 个调位
        rotated_major = MAJOR_PROFILE[-i:] + MAJOR_PROFILE[:-i]
        rotated_minor = MINOR_PROFILE[-i:] + MINOR_PROFILE[:-i]

        corr_major = get_correlation(rotated_major, histogram)
        corr_minor = get_correlation(rotated_minor, histogram)

        if corr_major > best_corr:
            best_corr = corr_major
            best_key = f"{PITCH_CLASSES[i]}_MAJOR"
        if corr_minor > best_corr:
            best_corr = corr_minor
            best_key = f"{PITCH_CLASSES[i]}_MINOR"

    return best_key

# ──────────────────────────────────────────────
# 2. 轨道类型判断
# ──────────────────────────────────────────────

def classify_track(inst: pretty_midi.Instrument, filename_lower: str):
    """
    依次通过：文件名关键字 → 轨道名关键字 → Channel / Program 判断轨道类型
    返回: "DRUMS" / "BASS" / "CHORD" / "MELODY" / "OTHER"
    """
    fname = filename_lower
    name  = inst.name.lower()

    # --- 鼓组 ---
    if inst.is_drum:
        return "DRUMS"
    if any(k in fname for k in ["kick", "snare", "hihat", "drum", "perc"]):
        return "DRUMS"
    if any(k in name for k in ["kick", "snare", "hihat", "drum", "perc"]):
        return "DRUMS"

    # --- 贝斯 ---
    if any(k in fname for k in ["bass", "808"]):
        return "BASS"
    if any(k in name for k in ["bass", "808"]):
        return "BASS"
    if 32 <= inst.program <= 39:
        return "BASS"

    # --- 和弦 ---
    chord_keywords = ["chord", "pad", "piano", "synth", "keys", "organ", "rhodes", "stabs", "poly"]
    if any(k in fname for k in chord_keywords):
        return "CHORD"
    if any(k in name for k in chord_keywords):
        return "CHORD"

    # --- 默认旋律 ---
    return "MELODY"

# ──────────────────────────────────────────────
# 3. 单小节音符序列生成器
# ──────────────────────────────────────────────

# MIDI pitch → 音符名映射（仅鼓组 GM 标准常见音）
GM_DRUM_MAP = {
    35: "KICK2", 36: "KICK",
    38: "SNARE", 40: "SNARE2",
    42: "HIHAT_CLOSED", 44: "HIHAT_PEDAL", 46: "HIHAT_OPEN",
    49: "CRASH", 51: "RIDE",
    37: "RIMSHOT", 39: "CLAP",
}

PITCH_NAMES = ["C","C#","D","D#","E","F","F#","G","G#","A","A#","B"]

def pitch_to_name(p):
    return f"{PITCH_NAMES[p % 12]}{p // 12 - 1}"

def quantize(t, resolution=16, bpm=128):
    """把绝对时间对齐到最近的 1/resolution 网格"""
    beat_dur = 60.0 / bpm
    grid_dur = beat_dur / (resolution / 4)  # e.g. 1/16 note duration
    return round(t / grid_dur) * grid_dur

def notes_to_tokens(notes, track_type, start_t, end_t, bpm=128):
    """将小节内的 Note 列表转换成 Token 字符串列表"""
    tokens = []
    in_bar = [n for n in notes if n.start >= start_t and n.start < end_t]
    in_bar.sort(key=lambda n: n.start)

    beat_dur = 60.0 / bpm
    bar_dur  = beat_dur * 4  # 假设 4/4 拍

    for n in in_bar:
        rel_start = (n.start - start_t) / bar_dur   # 0.0 ~ 1.0 归一化位置
        rel_dur   = (n.end - n.start) / bar_dur
        vel_bin   = round(n.velocity / 127.0 * 3)   # 0 ~ 3（4级力度，大幅压缩词表）

        # 时间位置 —— 量化到 16 步 grid，限制范围防止词表爆炸
        pos_step = min(15, max(0, round(rel_start * 16)))
        dur_step = min(4, max(1, round(rel_dur * 16)))  # 最多4步时值

        if track_type == "DRUMS":
            drum_name = GM_DRUM_MAP.get(n.pitch, f"DRUM_{n.pitch}")
            dur_step = min(2, dur_step)  # 鼓的时值最多2步
            tokens.append(f"D:{drum_name}:p{pos_step}:d{dur_step}:v{vel_bin}")
        else:
            # 按轨道类型限制音高范围，压缩词表
            if track_type == "BASS":
                clamped = max(24, min(59, n.pitch))   # C1-B3 (Bass range)
            elif track_type == "MELODY":
                clamped = max(48, min(83, n.pitch))   # C3-B5 (Melody range)
            else:  # CHORD
                clamped = max(36, min(71, n.pitch))   # C2-B4 (Chord range)
            note_name = pitch_to_name(clamped)
            tokens.append(f"N:{track_type}:{note_name}:p{pos_step}:d{dur_step}:v{vel_bin}")

    return tokens

# ──────────────────────────────────────────────
# 4. 能量等级映射
# ──────────────────────────────────────────────

def dt_to_level(dt):
    """将连续 D_t (0.0~1.0+) 映射到 8 个离散等级"""
    level = int(np.clip(np.ceil(dt * 8), 1, 8))
    return level

def get_struct_penalty(struct):
    """
    获取宏观段落能量衰减系数，
    防止如 Outro 全编鼓组算出的纯物理能量高过 Drop。
    """
    struct = struct.upper() if struct else ""
    weights = {
        "INTRO":  0.85, "INTRO2":  0.85,
        "BREAKDOWN": 0.80, "BREAKDOWN2": 0.80,
        "BUILDUP": 0.95, "BUILDUP2": 0.95,
        "DROP":   1.0,  "DROP2":   1.0,
        "OUTRO":  0.70, "OUTRO2":  0.70,
    }
    return weights.get(struct, 1.0)

# ──────────────────────────────────────────────
# 5. 主流程
# ──────────────────────────────────────────────

def process_file(path):
    """
    处理单个 MIDI 文件，返回一个 Token 序列（list of str）。
    若失败返回 None。
    """
    filename_lower = os.path.basename(path).lower()
    genre, struct, section_order, bpm = parse_filename(path)
    bpm = bpm or 128  # 若文件名里没有 BPM 则默认 128

    # 能量特征提取
    processor = MIDIEnergyProcessor(path)
    df = processor.process_song_dynamic_curve()
    if df is None or df.empty:
        return None

    # 应用宏观段落衰减系数
    penalty = get_struct_penalty(struct)
    energy_levels = [dt_to_level(v * penalty) for v in df['D_t'].tolist()]
    bars = processor.get_bar_boundaries()

    midi_data = processor.midi_data
    if midi_data is None:
        return None

    # 构建全局 Token 头
    key_token = estimate_key(midi_data)

    sequence = [
        f"[GENRE_{genre}]",
        f"[STRUCT_{struct}]",
        f"[SECTION_{section_order}]",   # 同类段落的第几次出现（1=首次）
        f"[KEY_{key_token}]",           # 增加调性标记
        f"[BPM_{bpm}]"
    ]

    # 逐小节处理
    for bar_idx, (bar_start, bar_end) in enumerate(bars):
        if bar_idx >= len(energy_levels):
            break
        level = energy_levels[bar_idx]

        sequence.append("[BAR_START]")
        sequence.append(f"[ENERGY_LEVEL_{level}]")

        # 遍历所有轨道，按顺序 DRUMS → BASS → CHORD → MELODY
        track_order = ["DRUMS", "BASS", "CHORD", "MELODY"]
        track_notes = {t: [] for t in track_order}

        for inst in midi_data.instruments:
            ttype = classify_track(inst, filename_lower)
            if ttype in track_notes:
                track_notes[ttype].extend(inst.notes)

        for ttype in track_order:
            notes = track_notes[ttype]
            if not notes:
                continue
            tok = notes_to_tokens(notes, ttype, bar_start, bar_end, bpm=bpm)
            if tok:
                sequence.append(f"[TRACK_{ttype}]")
                sequence.extend(tok)
                sequence.append(f"[TRACK_{ttype}_END]")

        sequence.append("[BAR_END]")

    sequence.append("[SONG_END]")
    return sequence


def build_dataset(raw_dir, out_dir):
    os.makedirs(out_dir, exist_ok=True)
    midi_files = glob.glob(os.path.join(raw_dir, "**/*.mid"), recursive=True)
    print(f"\nFound {len(midi_files)} MIDI files in '{raw_dir}'")

    output_jsonl = os.path.join(out_dir, "pulse_dataset.jsonl")
    output_vocab = os.path.join(out_dir, "pulse_vocab.json")

    all_vocab = set()
    success = 0

    with open(output_jsonl, "w", encoding="utf-8") as f:
        for path in tqdm(midi_files, desc="Tokenizing", unit="file"):
            seq = process_file(path)
            if seq is None:
                print(f"  [SKIP] {os.path.basename(path)}")
                continue

            # 写入 JSONL（每行一个序列）
            f.write(json.dumps(seq, ensure_ascii=False) + "\n")
            all_vocab.update(seq)
            success += 1
            print(f"  [OK]   {os.path.basename(path)}  →  {len(seq)} tokens")

    # 保存词汇表
    sorted_vocab = sorted(all_vocab)
    vocab_map = {tok: i for i, tok in enumerate(sorted_vocab)}
    with open(output_vocab, "w", encoding="utf-8") as f:
        json.dump(vocab_map, f, ensure_ascii=False, indent=2)

    print(f"\n{'='*50}")
    print(f"[DONE] Built {success}/{len(midi_files)} samples")
    print(f"[OUT]  Sequences  -> {output_jsonl}")
    print(f"[OUT]  Vocabulary -> {output_vocab}  ({len(vocab_map)} unique tokens)")


if __name__ == "__main__":
    raw_directory = r"d:\BigData\PycharmProject\TOMI-GPT\dataset\raw_processed"
    out_directory = r"d:\BigData\PycharmProject\TOMI-GPT\dataset\processed"
    build_dataset(raw_directory, out_directory)
