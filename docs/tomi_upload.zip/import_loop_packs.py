"""
PulseGPT — Multi-Track Loop Importer (v2.0)
=============================================================
核心升级：将同一"套件 (Kit)"下的 BASS / ACID / LEAD / CHORD / ARP 轨道
智能合并为单个多轨 MIDI 文件，彻底解决模型只能生成单轨的问题。

来源数据结构分析：
  Pack 1 (ACID):     25个 BASS/Acid Loop，命名规则 _N_KEY.mid (N=1..25)
  Pack 2 (DROP):     25个 LEAD Loop，      命名规则 _N_KEY.mid (N=1..25)
         → 相同索引 N 的 ACID + LEAD 合并为一个双轨 MIDI

  Pack 3 (Vol. 1):   按 Bass MIDI/, Chord MIDI/, Arp MIDI/ 等子文件夹分类
                     文件名规则 _XX(KEY).mid (XX=01..10)
         → 相同索引 XX 的多个轨道合并为一个多轨 MIDI

  Pack 4 (Vol. 2):   20个子文件夹（每个是一个 Loop 套件，已包含调性名）
                     每个子文件夹内有多个 MIDI 分轨
         → 每个子文件夹直接合并为一个多轨 MIDI
"""

import os
import glob
import re
import pretty_midi
from tqdm import tqdm
from collections import defaultdict

# ──────────────────────────────────────────────
# 1. 路径配置
# ──────────────────────────────────────────────
SOURCE_ACID = r"d:\BigData\PycharmProject\Dynamic-Music-Transformer\data\BIGROOM TECHNO ACID LOOPS MIDI"
SOURCE_DROP = r"d:\BigData\PycharmProject\Dynamic-Music-Transformer\data\BIGROOM TECHNO DROP LOOPS"
SOURCE_VOL1 = r"d:\BigData\PycharmProject\Dynamic-Music-Transformer\data\Bigroom Techno MIDI (Vol. 1)"
SOURCE_VOL2 = r"d:\BigData\PycharmProject\Dynamic-Music-Transformer\data\Melodic Techno MIDI (Vol. 2)"

RAW_DIR = r"d:\BigData\PycharmProject\TOMI-GPT\dataset\raw"

# ──────────────────────────────────────────────
# 2. 工具函数
# ──────────────────────────────────────────────

def parse_index_from_filename(filename):
    """从文件名中提取数字索引 (e.g., ACID_10_AM → 10, BASS_01(G) → 1)"""
    # 匹配 _NN_ 或 _NN( 格式
    m = re.search(r'[_\s]0*(\d+)[_(]', filename)
    if m:
        return int(m.group(1))
    # 备用：直接找独立数字
    m = re.search(r'(\d+)', filename)
    return int(m.group(1)) if m else 0

def parse_key_from_filename(filename):
    """从文件名提取调性，统一转换为 X_MAJOR / X_MINOR 格式"""
    fn = filename.upper()
    # Vol.1 格式: (G#) (A#) (C) 等
    m = re.search(r'\(([A-G]#?)\)', fn)
    if m:
        return f"{m.group(1)}_MAJOR"
    # Pack 1/2 格式: _AM _GM _F#M _D#M 等（M = Minor, MAJ = Major）
    m = re.search(r'_([A-G]#?)(M|MAJ|MIN|MINOR|MAJOR)?[._\s]', fn + "_")
    if m:
        note = m.group(1)
        mode = m.group(2) or "M"
        if mode in ("M", "MIN", "MINOR"):
            return f"{note}_MINOR"
        return f"{note}_MAJOR"
    return "C_MINOR"  # 无法识别时的默认值

def get_track_type(filename, folder_name=""):
    """根据文件名和子文件夹名推断轨道类型"""
    f = (filename + " " + folder_name).lower()
    if any(k in f for k in ["acid", "bass", "808", "sub"]): return "BASS"
    if any(k in f for k in ["chord", "pad", "piano", "keys", "rhodes", "stab", "poly"]): return "CHORD"
    if any(k in f for k in ["arp"]): return "CHORD"         # Arp 归 CHORD
    if any(k in f for k in ["lead", "melody", "drop lead", "synth"]): return "MELODY"
    return "MELODY"

def merge_midi_files(source_paths_with_types, output_path, bpm=130):
    """
    将多个 (midi_path, track_type) 合并为一个多轨 MIDI 文件
    Args:
        source_paths_with_types: list of (filepath, track_type_str)
        output_path: 输出文件路径
        bpm: 目标 BPM
    """
    combined = pretty_midi.PrettyMIDI(initial_tempo=bpm)
    has_notes = False

    for fpath, t_type in source_paths_with_types:
        try:
            pm = pretty_midi.PrettyMIDI(fpath)
            for inst in pm.instruments:
                new_inst = pretty_midi.Instrument(
                    program=inst.program,
                    is_drum=inst.is_drum,
                    name=t_type
                )
                new_inst.notes = inst.notes
                combined.instruments.append(new_inst)
                if inst.notes:
                    has_notes = True
        except Exception as e:
            print(f"    [WARN] 跳过损坏文件 {os.path.basename(fpath)}: {e}")

    if not has_notes:
        return False

    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    combined.write(output_path)
    return True


# ──────────────────────────────────────────────
# 3. Pack 1 + Pack 2：ACID(BASS) × DROP(LEAD) 交叉合并
#    相同编号配对，形成双轨 MIDI
# ──────────────────────────────────────────────

def import_acid_and_drop(output_dir, bpm_base=130):
    print("\n[Pack 1+2] 处理 ACID BASS + DROP LEAD（双轨交叉合并）")

    acid_files = sorted(glob.glob(os.path.join(SOURCE_ACID, "*.mid")))
    drop_files  = sorted(glob.glob(os.path.join(SOURCE_DROP, "*.mid")))

    # 建立索引 → 文件路径的字典
    acid_by_idx = {}
    for f in acid_files:
        idx = parse_index_from_filename(os.path.basename(f))
        acid_by_idx[idx] = f

    drop_by_idx = {}
    for f in drop_files:
        idx = parse_index_from_filename(os.path.basename(f))
        drop_by_idx[idx] = f

    count = 0
    all_indices = sorted(set(acid_by_idx.keys()) | set(drop_by_idx.keys()))

    for idx in tqdm(all_indices, desc="ACID+DROP Merge"):
        pairs = []

        if idx in acid_by_idx:
            pairs.append((acid_by_idx[idx], "BASS"))
        if idx in drop_by_idx:
            pairs.append((drop_by_idx[idx], "MELODY"))

        if not pairs:
            continue

        # 从 acid 文件名推调性
        key = parse_key_from_filename(os.path.basename(acid_by_idx.get(idx, drop_by_idx.get(idx, ""))))
        bpm = bpm_base + (idx % 5)  # 小幅抖动 130-134

        # 多轨或单轨均保存
        n_tracks = len(pairs)
        track_tag = "MULTITRACK" if n_tracks > 1 else "SINGLE"
        sec = (idx % 2) + 1  # Section 1 或 2

        out_name = f"TECHNO_ACIDDROP_KIT{idx:02d}_{track_tag}_KEY{key}_PATTERN{sec}_{bpm}.mid"
        out_path = os.path.join(output_dir, out_name)

        if merge_midi_files(pairs, out_path, bpm=bpm):
            count += 1

    print(f"  → 生成 {count} 个 合并样本")
    return count


# ──────────────────────────────────────────────
# 4. Pack 3 (Vol. 1)：按子文件夹 + 编号配对合并
# ──────────────────────────────────────────────

def import_vol1(output_dir, bpm_base=130):
    print("\n[Pack 3] 处理 Bigroom Techno Vol. 1（多轨按编号合并）")

    # 子文件夹 → 轨道类型映射
    folder_type_map = {
        "Acid MIDI":      "BASS",
        "Bass MIDI":      "BASS",
        "Chord MIDI":     "CHORD",
        "Arp MIDI":       "CHORD",
        "Drop Lead MIDI": "MELODY",
    }

    # 收集所有文件，按 index 分组
    # { index: [(filepath, track_type), ...] }
    kits = defaultdict(list)

    for folder_name, t_type in folder_type_map.items():
        folder_path = os.path.join(SOURCE_VOL1, folder_name)
        if not os.path.isdir(folder_path):
            # 尝试 glob 模糊匹配
            possible = glob.glob(os.path.join(SOURCE_VOL1, f"*{folder_name.split()[0]}*"))
            if possible:
                folder_path = possible[0]
            else:
                continue

        for fpath in glob.glob(os.path.join(folder_path, "*.mid")):
            idx = parse_index_from_filename(os.path.basename(fpath))
            kits[idx].append((fpath, t_type))

    count = 0
    for idx, pairs in tqdm(kits.items(), desc="Vol.1 Kit Merge"):
        if not pairs:
            continue

        # 从第一个文件推调性
        key = parse_key_from_filename(os.path.basename(pairs[0][0]))
        bpm = bpm_base + (idx % 5)
        sec = (idx % 2) + 1
        n_tracks = len(set(t for _, t in pairs))
        track_tag = "MULTITRACK" if n_tracks > 1 else "SINGLE"

        out_name = f"TECHNO_VOL1_KIT{idx:02d}_{track_tag}_KEY{key}_PATTERN{sec}_{bpm}.mid"
        out_path = os.path.join(output_dir, out_name)

        if merge_midi_files(pairs, out_path, bpm=bpm):
            count += 1

    print(f"  → 生成 {count} 个合并样本")
    return count


# ──────────────────────────────────────────────
# 5. Pack 4 (Vol. 2)：每个子文件夹就是一个完整 Loop Kit
# ──────────────────────────────────────────────

def import_vol2(output_dir, bpm_base=130):
    print("\n[Pack 4] 处理 Melodic Techno Vol. 2（每个子文件夹整体合并）")

    loop_dirs = [
        d for d in glob.glob(os.path.join(SOURCE_VOL2, "LOOP*"))
        if os.path.isdir(d)
    ]

    count = 0
    for loop_dir in tqdm(loop_dirs, desc="Vol.2 Loop Kit"):
        # LOOP 1 - E minor - Infinity → 提取调性 "E minor"
        dir_name = os.path.basename(loop_dir)
        key_m = re.search(r'-\s*([A-G]#?)\s*(major|minor|Major|Minor)', dir_name)
        key = "C_MINOR"
        if key_m:
            note = key_m.group(1).upper()
            mode = "MAJOR" if "major" in key_m.group(2).lower() else "MINOR"
            key = f"{note}_{mode}"

        # 提取 loop 编号
        num_m = re.search(r'LOOP\s*(\d+)', dir_name, re.IGNORECASE)
        loop_num = int(num_m.group(1)) if num_m else 0

        bpm = bpm_base + (loop_num % 5)
        sec = (loop_num % 2) + 1

        # 收集子文件夹内所有 MIDI，推断轨道类型
        pairs = []
        for fpath in glob.glob(os.path.join(loop_dir, "**/*.mid"), recursive=True):
            fname = os.path.basename(fpath)
            parent = os.path.basename(os.path.dirname(fpath))
            t_type = get_track_type(fname, parent)
            pairs.append((fpath, t_type))

        if not pairs:
            continue

        n_tracks = len(set(t for _, t in pairs))
        track_tag = "MULTITRACK" if n_tracks > 1 else "SINGLE"

        out_name = f"TECHNO_VOL2_LOOP{loop_num:02d}_{track_tag}_KEY{key}_PATTERN{sec}_{bpm}.mid"
        out_path = os.path.join(output_dir, out_name)

        if merge_midi_files(pairs, out_path, bpm=bpm):
            count += 1

    print(f"  → 生成 {count} 个合并样本")
    return count


# ──────────────────────────────────────────────
# 6. House 系列保留 (保持之前手动建立的 House 数据)
# ──────────────────────────────────────────────

def preserve_house_data(output_dir):
    """House 数据已经是高质量的，直接保留，不删除"""
    existing = glob.glob(os.path.join(output_dir, "HOUSE_*.mid"))
    print(f"\n[House] 保留现有 {len(existing)} 个 House 样本（不做修改）")
    return len(existing)


# ──────────────────────────────────────────────
# 7. 主流程
# ──────────────────────────────────────────────

def process_all_packs():
    os.makedirs(RAW_DIR, exist_ok=True)

    # 只清理旧的 TECHNO 批导入文件（不动 House 数据）
    old_techno = glob.glob(os.path.join(RAW_DIR, "TECHNO_*.mid"))
    for f in old_techno:
        os.remove(f)
    print(f"已清理 {len(old_techno)} 个旧的 Techno 导入文件")

    total = 0
    total += import_acid_and_drop(RAW_DIR)
    total += import_vol1(RAW_DIR)
    total += import_vol2(RAW_DIR)
    house = preserve_house_data(RAW_DIR)

    print(f"""
{'='*55}
[DONE] PulseGPT 导入完成！
  Techno 新生成:  {total}  个多轨/双轨合并样本
  House    保留:  {house}  个手动分段样本
  总计         :  {total + house}  个训练样本
  输出目录     :  {RAW_DIR}
{'='*55}

下一步: python build_pulse_dataset.py
""")

if __name__ == "__main__":
    process_all_packs()
