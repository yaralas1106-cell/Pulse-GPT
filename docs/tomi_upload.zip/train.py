import time
import torch
from torch.optim import AdamW
from torch.optim.lr_scheduler import CosineAnnealingLR

from tokenizer import PulseTokenizer
from dataset import get_dataloader
from model import PulseLlamaModel

def train():
    # 1. 硬件配置
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f"[{time.strftime('%H:%M:%S')}] 使用设备: {device}")

    # 2. 初始化模块
    tokenizer = PulseTokenizer()
    print(f"[{time.strftime('%H:%M:%S')}] 词表加载成功 | Vocab Size: {len(tokenizer)}")

    train_loader = get_dataloader(
        jsonl_path="dataset/processed/pulse_dataset.jsonl",
        tokenizer=tokenizer,
        batch_size=4,
        max_seq_len=1024,
        shuffle=True
    )

    # 3. 从零初始化模型（新词表 4771，不兼容旧权重）
    model = PulseLlamaModel(vocab_size=len(tokenizer), pad_token_id=tokenizer.pad_id).to(device)
    total_params = sum(p.numel() for p in model.parameters()) / 1e6
    print(f"[{time.strftime('%H:%M:%S')}] 模型初始化完毕 | 参数量: {total_params:.2f} M")

    # 4. 优化器：余弦退火调度 + 梯度裁剪，多轨数据训练更稳定
    epochs = 200
    optimizer = AdamW(model.parameters(), lr=5e-4, weight_decay=0.01)
    scheduler = CosineAnnealingLR(optimizer, T_max=epochs, eta_min=1e-5)

    print(f"\n============== PulseGPT 多轨训练启动 ({epochs} Epochs) ==============\n")

    model.train()
    best_loss = float('inf')
    best_epoch = 0

    for epoch in range(1, epochs + 1):
        epoch_loss = 0.0
        steps = 0

        for batch_idx, batch in enumerate(train_loader):
            start_time = time.time()
            optimizer.zero_grad()

            input_ids      = batch['input_ids'].to(device)
            attention_mask = batch['attention_mask'].to(device)
            labels         = batch['labels'].to(device)

            loss, _ = model(input_ids, attention_mask, labels)

            loss.backward()
            # 梯度裁剪，防止多轨长序列梯度爆炸
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            optimizer.step()

            epoch_loss += loss.item()
            steps += 1

            if (epoch % 10 == 0 or epoch == 1) and batch_idx == 0:
                step_time = time.time() - start_time
                print(f"  [Epoch {epoch:03d}/{epochs}] Loss: {loss.item():.4f} | "
                      f"LR: {optimizer.param_groups[0]['lr']:.6f} | {step_time:.2f}s/step")

        scheduler.step()
        avg_loss = epoch_loss / steps

        # 每 10 轮打印一次摘要
        if epoch % 10 == 0 or epoch == 1:
            print(f"==> Epoch {epoch:03d} | Avg Loss: {avg_loss:.4f}\n")

        # 保存最优模型（best checkpoint）
        if avg_loss < best_loss:
            best_loss = avg_loss
            best_epoch = epoch
            torch.save(model.state_dict(), "pulsegpt_best.pt")

    # 保存最终模型
    torch.save(model.state_dict(), "pulsegpt_final.pt")
    print(f"\n{'='*55}")
    print(f"训练完成！")
    print(f"  最优 Epoch : {best_epoch}  |  Best Loss: {best_loss:.4f}")
    print(f"  最优权重   : pulsegpt_best.pt")
    print(f"  最终权重   : pulsegpt_final.pt")
    print(f"{'='*55}")

if __name__ == "__main__":
    train()
