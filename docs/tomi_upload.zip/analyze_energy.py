"""
analyze_energy.py — 分析 pulse_dataset.jsonl 中每个样本的能量分布
"""
import json

JSONL = r'd:\BigData\PycharmProject\PulseGPT\dataset\processed\pulse_dataset.jsonl'

results = []
with open(JSONL) as f:
    for line in f:
        line = line.strip()
        if not line:
            continue
        tokens = json.loads(line)
        genre  = next((t for t in tokens if t.startswith('[GENRE_')),  '[GENRE_UNKNOWN]')
        struct = next((t for t in tokens if t.startswith('[STRUCT_')), '[STRUCT_UNKNOWN]')
        levels = [int(t.split('_')[-1].replace(']',''))
                  for t in tokens if t.startswith('[ENERGY_LEVEL_')]
        if levels:
            results.append({
                'genre':  genre.replace('[GENRE_','').replace(']',''),
                'struct': struct.replace('[STRUCT_','').replace(']',''),
                'bars':   len(levels),
                'avg':    round(sum(levels)/len(levels), 2),
                'min':    min(levels),
                'max':    max(levels),
                'levels': levels,
            })

# 按能量均值排序（高→低）
results.sort(key=lambda x: x['avg'], reverse=True)

print(f"{'样本':<30} {'小节':>4} {'均值':>5} {'最低':>4} {'最高':>4}  能量曲线（每格=1小节）")
print('-' * 95)

for r in results:
    name = f"{r['genre']}_{r['struct']}"
    # ASCII 能量条形图（每个数字代表一小节）
    bar = ''.join(str(e) for e in r['levels'][:32])
    if len(r['levels']) > 32:
        bar += f"...+{len(r['levels'])-32}"
    print(f"{name:<30} {r['bars']:>4} {r['avg']:>5} {r['min']:>4} {r['max']:>4}  {bar}")

print()
print("=== 按段落类型统计 ===")
from collections import defaultdict
struct_stats = defaultdict(list)
for r in results:
    struct_stats[r['struct']].append(r['avg'])

for s in sorted(struct_stats):
    vals = struct_stats[s]
    print(f"  {s:<15}: 样本数={len(vals):>2}, 平均能量={sum(vals)/len(vals):.2f}, "
          f"范围=[{min(vals):.2f}, {max(vals):.2f}]")
