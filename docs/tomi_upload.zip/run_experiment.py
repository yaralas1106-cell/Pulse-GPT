"""
PulseGPT — run_experiment.py
==============================
批量实验脚本：自动生成 N 个样本，评估所有指标，输出论文所需的统计表格。

流程：
  1. 用 PulseGPT（有控制标签）生成 N 个 MIDI
  2. 用 Baseline（无控制）生成 N 个 MIDI
  3. 对所有样本运行 evaluate.py 的 5 项指标
  4. 计算均值 ± 标准差
  5. 输出 LaTeX 格式的论文表格

用法：
  python run_experiment.py --n 10
  python run_experiment.py --n 10 --temperature 0.9
"""

import os
import json
import argparse
import numpy as np
import torch
import torch.nn.functional as F

from tokenizer import PulseTokenizer
from model import PulseLlamaModel
from evaluate import (
    pitch_class_entropy, groove_consistency,
    scale_consistency, multi_track_rate, energy_arc_alignment
)


# ──────────────────────────────────────────────────────────────────────────────
# 1. 内联生成器（不依赖外部脚本，直接调用）
# ──────────────────────────────────────────────────────────────────────────────

import pretty_midi

PITCH_NAMES = ["C","C#","D","D#","E","F","F#","G","G#","A","A#","B"]
GM_DRUMS = {
    'KICK': 36, 'KICK2': 35, 'SNARE': 38, 'SNARE2': 40,
    'HIHAT_CLOSED': 42, 'HIHAT_OPEN': 46, 'HIHAT_PEDAL': 44,
    'CLAP': 39, 'RIMSHOT': 37, 'CRASH': 49, 'RIDE': 51,
}

def name_to_pitch(note_name):
    try:
        pc = PITCH_NAMES.index(note_name[:-1])
        oct_ = int(note_name[-1])
        return (oct_ + 1) * 12 + pc
    except:
        return 60

def tokens_to_midi(tokens, output_path, bpm=128):
    pm = pretty_midi.PrettyMIDI(initial_tempo=bpm)
    beat_dur = 60.0 / bpm
    bar_dur  = beat_dur * 4
    TRACK_PROGRAMS = {'BASS': 32, 'CHORD': 0, 'MELODY': 80, 'DRUMS': 0}

    instruments = {}
    current_track = None
    current_bar   = 0
    bar_start_t   = 0.0

    for tok in tokens:
        if tok == '[BAR_START]':
            bar_start_t = current_bar * bar_dur
        elif tok == '[BAR_END]':
            current_bar += 1
        elif tok.startswith('[TRACK_') and not tok.endswith('_END]'):
            tname = tok[7:-1]
            current_track = tname
            if tname not in instruments:
                instruments[tname] = pretty_midi.Instrument(
                    program=TRACK_PROGRAMS.get(tname, 0),
                    is_drum=(tname == 'DRUMS'), name=tname
                )
        elif tok.endswith('_END]') and tok.startswith('[TRACK_'):
            current_track = None
        elif tok.startswith('N:') and current_track:
            parts = tok.split(':')
            if len(parts) >= 6:
                try:
                    note_name = parts[2]
                    pos_step  = int(parts[3][1:])
                    dur_step  = int(parts[4][1:])
                    vel_bin   = int(parts[5][1:])
                    pitch     = name_to_pitch(note_name)
                    vel       = max(20, int(vel_bin / 7.0 * 127))
                    step_dur  = bar_dur / 16.0
                    start_t   = bar_start_t + pos_step * step_dur
                    end_t     = start_t + max(step_dur, dur_step * step_dur)
                    instruments[current_track].notes.append(
                        pretty_midi.Note(velocity=vel, pitch=pitch, start=start_t, end=end_t)
                    )
                except: pass
        elif tok.startswith('D:') and current_track == 'DRUMS':
            parts = tok.split(':')
            if len(parts) >= 5:
                try:
                    drum_name = parts[1]
                    pos_step  = int(parts[2][1:])
                    vel_bin   = int(parts[4][1:])
                    pitch     = GM_DRUMS.get(drum_name, 36)
                    vel       = max(20, int(vel_bin / 7.0 * 127))
                    step_dur  = bar_dur / 16.0
                    start_t   = bar_start_t + pos_step * step_dur
                    end_t     = start_t + step_dur
                    instruments['DRUMS'].notes.append(
                        pretty_midi.Note(velocity=vel, pitch=pitch, start=start_t, end=end_t)
                    )
                except: pass

    for inst in instruments.values():
        if inst.notes:
            pm.instruments.append(inst)
    if pm.instruments:
        pm.write(output_path)
        return True
    return False


@torch.no_grad()
def generate_tokens(model, tokenizer, prompt_tokens, device,
                    max_new_tokens=512, temperature=0.85, top_k=50):
    input_ids = [tokenizer.bos_id] + [tokenizer.t2i.get(t, tokenizer.unk_id) for t in prompt_tokens]
    generated  = input_ids[:]
    eos_id     = tokenizer.eos_id

    for _ in range(max_new_tokens):
        x = torch.tensor([generated[-512:]], dtype=torch.long).to(device)
        _, logits = model(x, attention_mask=None, labels=None)
        logits = logits[0, -1, :] / temperature
        if top_k > 0:
            top_vals, _ = torch.topk(logits, top_k)
            logits[logits < top_vals[-1]] = float('-inf')
        probs   = F.softmax(logits, dim=-1)
        next_id = torch.multinomial(probs, num_samples=1).item()
        generated.append(next_id)
        if next_id == eos_id:
            break

    return [tokenizer.i2t.get(i, '<UNK>') for i in generated]


# ──────────────────────────────────────────────────────────────────────────────
# 2. 单个样本的完整评估
# ──────────────────────────────────────────────────────────────────────────────

def evaluate_one(midi_path, key='C_MINOR', struct='PATTERN', bpm=128):
    """对单个 MIDI 文件计算所有指标，返回 dict"""
    if not os.path.exists(midi_path):
        return None
    return {
        'pce': pitch_class_entropy(midi_path),
        'gc':  groove_consistency(midi_path),
        'sc':  scale_consistency(midi_path, key=key),
        'eaa': energy_arc_alignment(midi_path, target_struct=struct, bpm=bpm)['eaa_distance'],
        'mtr': multi_track_rate(midi_path)['n_tracks'],
    }


# ──────────────────────────────────────────────────────────────────────────────
# 3. 主实验流程
# ──────────────────────────────────────────────────────────────────────────────

def run_experiment(n_samples=10, temperature=0.85, bpm=128):
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    tokenizer = PulseTokenizer()

    # 输出目录
    os.makedirs("outputs/pulsegpt",  exist_ok=True)
    os.makedirs("outputs/baseline",  exist_ok=True)

    # ── 加载两个模型 ──
    print(f"\n{'='*60}")
    print(f"  PulseGPT 实验  |  样本数: {n_samples}  |  Temperature: {temperature}")
    print(f"{'='*60}\n")

    pulsegpt_model = PulseLlamaModel(vocab_size=len(tokenizer), pad_token_id=tokenizer.pad_id).to(device)
    pulsegpt_model.load_state_dict(torch.load("pulsegpt_best.pt", map_location=device))
    pulsegpt_model.eval()
    print(f"[OK] PulseGPT  权重: pulsegpt_best.pt")

    baseline_model = PulseLlamaModel(vocab_size=len(tokenizer), pad_token_id=tokenizer.pad_id).to(device)
    baseline_model.load_state_dict(torch.load("baseline_best.pt", map_location=device))
    baseline_model.eval()
    print(f"[OK] Baseline  权重: baseline_best.pt\n")

    # PulseGPT Prompt（有控制标签）
    pulsegpt_prompt = ["[GENRE_HOUSE]", "[STRUCT_DROP]", "[SECTION_1]",
                       "[KEY_C_MINOR]", "[BPM_128]", "[BAR_START]"]
    # Baseline Prompt（无控制）
    baseline_prompt = ["[BAR_START]"]

    pulsegpt_results = []
    baseline_results = []

    for i in range(1, n_samples + 1):
        # ── PulseGPT ──
        print(f"[{i:02d}/{n_samples}] PulseGPT 生成中...", end=" ", flush=True)
        pg_path = f"outputs/pulsegpt/sample_{i:02d}.mid"
        pg_tokens = generate_tokens(pulsegpt_model, tokenizer, pulsegpt_prompt,
                                    device, max_new_tokens=600, temperature=temperature)
        ok = tokens_to_midi(pg_tokens, pg_path, bpm=bpm)
        if ok:
            r = evaluate_one(pg_path, key='C_MINOR', struct='DROP', bpm=bpm)
            if r:
                pulsegpt_results.append(r)
                print(f"PCE={r['pce']:.2f} SC={r['sc']:.2f} EAA={r['eaa']:.4f}")
            else:
                print("skip (eval failed)")
        else:
            print("skip (empty)")

        # ── Baseline ──
        print(f"[{i:02d}/{n_samples}] Baseline  生成中...", end=" ", flush=True)
        bl_path = f"outputs/baseline/sample_{i:02d}.mid"
        bl_tokens = generate_tokens(baseline_model, tokenizer, baseline_prompt,
                                    device, max_new_tokens=600, temperature=temperature)
        ok = tokens_to_midi(bl_tokens, bl_path, bpm=bpm)
        if ok:
            r = evaluate_one(bl_path, key='C_MINOR', struct='DROP', bpm=bpm)
            if r:
                baseline_results.append(r)
                print(f"PCE={r['pce']:.2f} SC={r['sc']:.2f} EAA={r['eaa']:.4f}")
            else:
                print("skip (eval failed)")
        else:
            print("skip (empty)")

    # ── 统计汇总 ──
    def stats(results, key):
        vals = [r[key] for r in results if r[key] != -1.0]
        return np.mean(vals), np.std(vals)

    print(f"\n{'='*60}")
    print(f"  实验结果汇总（N={len(pulsegpt_results)} PulseGPT / {len(baseline_results)} Baseline）")
    print(f"{'='*60}")

    metrics = [
        ('PCE', 'pce', 'up'),
        ('GC',  'gc',  'up'),
        ('SC',  'sc',  'up'),
        ('EAA', 'eaa', 'down'),
        ('MTR', 'mtr', 'up'),
    ]

    table = {}
    for name, key, direction in metrics:
        pg_mean, pg_std = stats(pulsegpt_results, key)
        bl_mean, bl_std = stats(baseline_results, key)
        table[name] = {'pulsegpt': (pg_mean, pg_std), 'baseline': (bl_mean, bl_std)}
        arrow = "↑" if direction == "up" else "↓"
        winner = "PulseGPT" if (direction == "up" and pg_mean > bl_mean) or (direction == "down" and pg_mean < bl_mean) else "Baseline"
        print(f"  {name:4s} {arrow}  Baseline: {bl_mean:.4f}±{bl_std:.4f}  |  PulseGPT: {pg_mean:.4f}±{pg_std:.4f}  [{winner}]")

    # ── LaTeX 表格 ──
    print(f"\n{'─'*60}")
    print("  LaTeX Table（直接粘贴到论文）:")
    print(f"{'─'*60}")
    print(r"\begin{table}[h]")
    print(r"\centering")
    print(r"\caption{Comparison of PulseGPT and Baseline on MIDI Generation Quality}")
    print(r"\label{tab:results}")
    print(r"\begin{tabular}{lcccc}")
    print(r"\hline")
    print(r"Metric & Direction & Baseline & PulseGPT (Ours) & $\Delta$ \\")
    print(r"\hline")
    for name, key, direction in metrics:
        bl_m, bl_s   = table[name]['baseline']
        pg_m, pg_s   = table[name]['pulsegpt']
        delta = ((pg_m - bl_m) / abs(bl_m) * 100) if bl_m != 0 else 0
        arrow = r"$\uparrow$" if direction == "up" else r"$\downarrow$"
        sign = "+" if delta >= 0 else ""
        print(f"{name} & {arrow} & {bl_m:.4f}$\\pm${bl_s:.4f} & \\textbf{{{pg_m:.4f}}}$\\pm${pg_s:.4f} & {sign}{delta:.1f}\\% \\\\")
    print(r"\hline")
    print(r"\end{tabular}")
    print(r"\end{table}")

    # 保存 JSON
    out = {'pulsegpt': pulsegpt_results, 'baseline': baseline_results}
    with open("outputs/experiment_results.json", "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2)
    print(f"\n[DONE] 结果保存: outputs/experiment_results.json")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--n',           type=int,   default=10,   help='每个模型生成的样本数')
    parser.add_argument('--temperature', type=float, default=0.85, help='生成温度')
    parser.add_argument('--bpm',         type=int,   default=128,  help='BPM')
    args = parser.parse_args()

    run_experiment(n_samples=args.n, temperature=args.temperature, bpm=args.bpm)
