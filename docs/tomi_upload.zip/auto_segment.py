"""
auto_segment.py
─────────────────────────────────────────────────────────────────────────────
从整轨 MIDI 文件（完整 Arrangement 导出）自动检测段落边界，
基于多轨乐器同时活跃情况推断 Intro / Drop / Breakdown / Outro，
然后将每个段落的音符切片合并输出为独立的 MIDI 文件，
送入 dataset/raw/ 准备 Tokenization。

用法:
  python auto_segment.py --input_dir "path/to/House007" --bpm 124 --song_id House007
─────────────────────────────────────────────────────────────────────────────
"""
import os, sys, copy, argparse
from collections import defaultdict
import pretty_midi

# ── 段落推断规则（优先级从高到低）────────────────────────────────────────────
def infer_struct(active_tracks):
    """
    根据本小节活跃的轨道集合推断段落类型。
    active_tracks: set of track name keywords (lower-case)
    """
    has_bass   = any('bass' in t for t in active_tracks)
    has_lead   = any('lead' in t or 'synth' in t or 'melody' in t for t in active_tracks)
    has_drums  = any(k in t for t in active_tracks for k in ['kick','snare','clap'])
    has_hihat  = any('hat' in t or 'hh' in t for t in active_tracks)
    has_chord  = any('chord' in t or 'pad' in t for t in active_tracks)
    has_open   = any('open' in t for t in active_tracks)

    if not has_drums and not has_bass:
        return "Breakdown"      # 完全空鼓 + 无 Bass → 纯 Breakdown
    if not has_drums and has_chord:
        return "Breakdown"      # 有和弦但无鼓
    if has_lead and has_bass and has_drums and (has_hihat or has_open):
        return "Drop"           # 全编制 → Drop
    if has_bass and has_drums and not has_lead:
        return "Drop"           # 有 Bass + 鼓 but 无 Lead 也算 Drop（常见 minimal house）
    if has_drums and not has_bass:
        return "Intro"          # 有鼓但无 Bass → Intro/Outro 过渡区
    return "Intro"              # fallback


def load_tracks(folder):
    """读取文件夹内所有 MIDI，返回 { track_name: [notes] }"""
    tracks = {}
    for fname in os.listdir(folder):
        if not fname.lower().endswith(('.mid', '.midi')):
            continue
        path = os.path.join(folder, fname)
        key = os.path.splitext(fname)[0].lower()
        # 去掉 SongID 前缀（如 house007_）
        parts = key.split('_')
        key = '_'.join(parts[1:]) if len(parts) > 1 else key
        pm = pretty_midi.PrettyMIDI(path)
        notes = [n for inst in pm.instruments for n in inst.notes]
        tracks[key] = (fname, notes)
    return tracks


def detect_sections(tracks, bpm):
    """
    逐小节推断活跃轨道集合 → 段落类型，
    合并相邻相同段落 → 返回 [(struct, start_bar, end_bar), ...]
    """
    spbar = (60.0 / bpm) * 4  # 秒/小节

    all_notes = [(n, tname) for tname, (_, notes) in tracks.items() for n in notes]
    if not all_notes:
        return []

    max_time = max(n.end for n, _ in all_notes)
    total_bars = int(max_time / spbar) + 2

    bar_structs = []
    for bar in range(total_bars):
        t0, t1 = bar * spbar, (bar + 1) * spbar
        active = {tname for tname, (_, notes) in tracks.items()
                  if any(t0 <= n.start < t1 for n in notes)}
        struct = infer_struct(active) if active else None
        bar_structs.append(struct)

    # Trim trailing Nones
    while bar_structs and bar_structs[-1] is None:
        bar_structs.pop()

    # 前向填充 None
    last = None
    for i, s in enumerate(bar_structs):
        if s is None:
            bar_structs[i] = last
        else:
            last = s

    # 合并连续相同段落
    sections = []
    cur_struct = bar_structs[0]
    cur_start  = 0
    for i, s in enumerate(bar_structs[1:], 1):
        if s != cur_struct:
            sections.append((cur_struct, cur_start, i - 1))
            cur_struct = s
            cur_start  = i
    sections.append((cur_struct, cur_start, len(bar_structs) - 1))

    return sections, spbar


def slice_and_merge(tracks, sections, spbar, out_dir, song_id, bpm):
    """
    将每个段落的音符切片，合并为独立 MIDI 输出。
    同段落出现多次时自动编号（Drop → Drop, Drop2...）
    """
    os.makedirs(out_dir, exist_ok=True)
    struct_count = defaultdict(int)

    for struct, bar_start, bar_end in sections:
        if bar_end - bar_start < 1:
            continue  # 跳过单小节噪声

        t0 = bar_start * spbar
        t1 = (bar_end + 1) * spbar

        struct_count[struct] += 1
        suffix = "" if struct_count[struct] == 1 else str(struct_count[struct])
        out_name = f"{song_id}_{struct}{suffix}_{int(bpm)}.mid"
        out_path = os.path.join(out_dir, out_name)

        merged = pretty_midi.PrettyMIDI(initial_tempo=bpm)
        drum_inst = pretty_midi.Instrument(program=0, is_drum=True, name="Drums")

        for tname, (orig_fname, notes) in tracks.items():
            fname_lower = orig_fname.lower()
            is_drum = any(k in fname_lower for k in
                          ['kick', 'snare', 'clap', 'hihat', 'hat', 'hh', 'perc', 'crash', 'ride', 'open'])

            section_notes = [n for n in notes if t0 <= n.start < t1]
            if not section_notes:
                continue

            if is_drum:
                # 决定 GM pitch
                if 'kick' in fname_lower:     pitch = 36
                elif 'snare' in fname_lower:   pitch = 38
                elif 'clap' in fname_lower:    pitch = 39
                elif 'open' in fname_lower:    pitch = 46
                elif 'crash' in fname_lower:   pitch = 49
                elif 'ride' in fname_lower:    pitch = 51
                else:                          pitch = 42  # closed hihat default
                for n in section_notes:
                    nn = copy.deepcopy(n)
                    nn.start -= t0
                    nn.end   -= t0
                    nn.pitch  = pitch
                    drum_inst.notes.append(nn)
            else:
                # 非鼓轨道名识别
                tname_norm = "Melody"
                if 'bass' in fname_lower:
                    tname_norm = "Bass"
                elif any(k in fname_lower for k in ['chord', 'pad', 'stab']):
                    tname_norm = "Chord"
                elif any(k in fname_lower for k in ['lead', 'synth', 'melody']):
                    tname_norm = "Melody"

                inst = pretty_midi.Instrument(program=0, is_drum=False, name=tname_norm)
                for n in section_notes:
                    nn = copy.deepcopy(n)
                    nn.start -= t0
                    nn.end   -= t0
                    inst.notes.append(nn)
                merged.instruments.append(inst)

        if drum_inst.notes:
            drum_inst.notes.sort(key=lambda x: x.start)
            merged.instruments.append(drum_inst)

        if any(inst.notes for inst in merged.instruments):
            merged.write(out_path)
            total_notes = sum(len(inst.notes) for inst in merged.instruments)
            print(f"  [OK] {out_name:<40} bars {bar_start+1:>3}-{bar_end+1:>3}  notes={total_notes}")
        else:
            print(f"  [SKIP] {out_name} — 无有效音符")


def parse_manual_sections(sections_str):
    """
    解析手动指定的段落字符串。
    格式: "Intro:1-33,Drop:33-65,Breakdown:65-81,Drop:81-113,Outro:199-215"
    注意: 结束小节是 exclusive（不含），与 Python slice 一致。
    """
    sections = []
    for part in sections_str.split(','):
        part = part.strip()
        name, bars = part.split(':')
        start, end = bars.split('-')
        # 转为 0-indexed，end 是 exclusive
        sections.append((name.strip().capitalize(), int(start)-1, int(end)-2))
    return sections


def main():
    parser = argparse.ArgumentParser(description="从完整 Arrangement MIDI 自动分段并合并")
    parser.add_argument("--input_dir",  required=True)
    parser.add_argument("--bpm",        type=float, required=True)
    parser.add_argument("--song_id",    required=True, help="如 House007")
    parser.add_argument("--out_dir",    default=None)
    parser.add_argument("--no_rebuild", action="store_true")
    parser.add_argument("--sections",   default=None,
                        help='手动指定段落，格式: "Intro:1-33,Drop:33-65,Breakdown:65-81"')
    args = parser.parse_args()

    RAW_DIR = args.out_dir or os.path.join(os.path.dirname(__file__), "dataset", "raw")
    BUILD_SCRIPT = os.path.join(os.path.dirname(__file__), "build_pulse_dataset.py")

    print(f"\n正在读取 {args.input_dir} ...")
    tracks = load_tracks(args.input_dir)
    print(f"  找到 {len(tracks)} 条轨道: {list(tracks.keys())}")

    if args.sections:
        # ── 手动模式 ──────────────────────────────────────────────────────
        sections = parse_manual_sections(args.sections)
        spbar = (60.0 / args.bpm) * 4
        print(f"\n使用手动指定段落 ({len(sections)} 段):")
        for struct, s, e in sections:
            print(f"  {struct:<15} Bar {s+1:>3} → {e+2:>3}  ({e-s+1} 小节)")
    else:
        # ── 自动检测模式 ───────────────────────────────────────────────────
        result = detect_sections(tracks, args.bpm)
        sections, spbar = result
        print(f"\n自动检测到 {len(sections)} 个段落:")
        for struct, s, e in sections:
            print(f"  {struct:<15} Bar {s+1:>3} → {e+2:>3}  ({e-s+1} 小节)")

    print(f"\n开始切片合并 → {RAW_DIR}")
    slice_and_merge(tracks, sections, spbar, RAW_DIR, args.song_id, args.bpm)

    if not args.no_rebuild:
        print("\n重建 JSONL 数据集...")
        import subprocess
        subprocess.run([sys.executable, BUILD_SCRIPT], cwd=os.path.dirname(__file__))


if __name__ == "__main__":
    main()

