import sys
import os
sys.path.append(r'd:\BigData\PycharmProject\PulseGPT')
from dataset_processor import MIDIEnergyProcessor

file_path = r'd:\BigData\PycharmProject\Dynamic-Music-Transformer\data\House002_Bass_Intro.mid'
processor = MIDIEnergyProcessor(file_path)
df = processor.process_song_dynamic_curve()
if df is not None and not df.empty:
    print("Extracted Energy Features:")
    print(df[['bar_index', 'density', 'velocity', 'kick_count', 'pitch', 'D_t']])
else:
    print("Could not compute energy. Make sure the file has notes.")
