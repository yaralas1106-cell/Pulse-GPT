import torch
import torch.nn.functional as F
import pretty_midi
import json
import os
from tokenizer import PulseTokenizer
from model import PulseLlamaModel

class PulseGenerator:
    def __init__(self, model_path="pulsegpt_best.pt", vocab_path="dataset/processed/pulse_vocab.json"):
        self.tokenizer = PulseTokenizer(vocab_path)
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        
        # 加载模型架构
        self.model = PulseLlamaModel(vocab_size=len(self.tokenizer), pad_token_id=self.tokenizer.pad_id)
        
        # 加载权重
        if os.path.exists(model_path):
            self.model.load_state_dict(torch.load(model_path, map_location=self.device))
            print(f"成功加载模型权重: {model_path}")
        else:
            print(f"警告: 未找到权重文件 {model_path}，将使用随机初始化权重生成。")
            
        self.model.to(self.device)
        self.model.eval()

    def generate(self, prompt_tokens, max_new_tokens=1000, temperature=0.7, top_p=0.9, repetition_penalty=1.2):
        """
        使用 HuggingFace 官方 generate 方法，支持重复惩罚和更高级的采样
        """
        input_ids = torch.tensor([self.tokenizer.encode(prompt_tokens, add_eos=False)], dtype=torch.long).to(self.device)
        
        with torch.no_grad():
            output_ids = self.model.model.generate(
                input_ids=input_ids,
                max_new_tokens=max_new_tokens,
                do_sample=True,
                temperature=temperature,
                top_p=top_p,
                repetition_penalty=repetition_penalty,
                pad_token_id=self.tokenizer.pad_id,
                eos_token_id=self.tokenizer.eos_id
            )
            
        return self.tokenizer.decode(output_ids[0].tolist())

    def tokens_to_midi(self, tokens, output_path="generated_output.mid", default_bpm=128):
        """
        将 Token 序列解析并保存为真实的 MIDI 文件
        """
        pm = pretty_midi.PrettyMIDI(initial_tempo=default_bpm)
        
        # 创建轨道映射
        # DRUMS 在 PrettyMIDI 中通常是 is_drum=True
        tracks = {
            "DRUMS": pretty_midi.Instrument(program=0, is_drum=True, name="DRUMS"),
            "BASS": pretty_midi.Instrument(program=38, name="BASS"), # Slap Bass
            "CHORD": pretty_midi.Instrument(program=0, name="CHORD"), # Piano/Synth
            "MELODY": pretty_midi.Instrument(program=81, name="MELODY"), # Lead
        }
        
        # 鼓组 Pitch 映射 (还原 midi_merger.py 的对应)
        drum_map = {
            "KICK": 36, "SNARE": 38, "CLAP": 39, 
            "HIHAT_CLOSED": 42, "HIHAT_OPEN": 46, "HIHAT_FOOT": 44,
            "CRASH": 49, "RIDE": 51
        }

        current_bar = -1
        bpm = default_bpm
        
        # 遍历生成的 Token
        for token in tokens:
            if token.startswith("[BPM_"):
                try: bpm = int(token.replace("[BPM_", "").replace("]", ""))
                except: pass
                pm.get_tempo_changes() # 更新
            
            if token == "[BAR_START]":
                current_bar += 1
                continue
            
            if current_bar < 0: continue # 还没开始小节
            
            # 计算当前小节的起始时间 (假设 4/4 拍)
            bar_start_time = current_bar * (240.0 / bpm)
            sixteenth_duration = (60.0 / bpm) / 4.0
            
            # 解析音符：N:TRACK:NOTE:pP:dD:vV
            if token.startswith("N:"):
                parts = token.split(":")
                if len(parts) < 6: continue
                track_name = parts[1]
                note_name = parts[2]
                pos = int(parts[3][1:])  # pX
                dur = int(parts[4][1:])  # dX
                vel = int(parts[5][1:])  # vX
                
                if track_name in tracks:
                    try:
                        pitch = pretty_midi.note_name_to_number(note_name)
                        start = bar_start_time + pos * sixteenth_duration
                        end = start + dur * sixteenth_duration
                        velocity = min(127, vel * 16)
                        
                        note = pretty_midi.Note(velocity=velocity, pitch=pitch, start=start, end=end)
                        tracks[track_name].notes.append(note)
                    except: pass
                    
            # 解析鼓组：D:INSTRUMENT:pP:dD:vV
            elif token.startswith("D:"):
                parts = token.split(":")
                if len(parts) < 5: continue
                inst_name = parts[1]
                pos = int(parts[2][1:])
                dur = int(parts[3][1:])
                vel = int(parts[4][1:])
                
                if inst_name in drum_map:
                    pitch = drum_map[inst_name]
                    start = bar_start_time + pos * sixteenth_duration
                    end = start + dur * sixteenth_duration
                    velocity = min(127, vel * 16)
                    
                    note = pretty_midi.Note(velocity=velocity, pitch=pitch, start=start, end=end)
                    tracks["DRUMS"].notes.append(note)

        # 将有音符的轨道加入文件
        for t in tracks.values():
            if len(t.notes) > 0:
                pm.instruments.append(t)
        
        pm.write(output_path)
        print(f"MIDI 文件已保存至: {output_path}")

if __name__ == "__main__":
    gen = PulseGenerator()
    
    # 设定生成 Prompt: 尝试我们刚刚扩充的 Techno 130BPM 风格
    # 使用 [STRUCT_PATTERN] 标签来调用那些 loop 包里的灵感
    prompt = ["[GENRE_HOUSE]", "[STRUCT_DROP]", "[SECTION_1]", "[KEY_A_MINOR]", "[BPM_128]", "[BAR_START]"]
    
    print(f"正在根据 Prompt 生成音符: {prompt} ...")
    # Temperature 0.85: 保持 Techno 的稳定性，同时允许适度的创意跳跃
    generated_tokens = gen.generate(prompt, max_new_tokens=2000, temperature=0.85, top_p=0.92)
    
    print("\n生成完成，词表规模: ", len(gen.tokenizer))
    print("前 30 个 Token 预览:")
    print(generated_tokens[:30])
    
    # 保存结果
    output_fn = "techno_130bpm_post_train.mid"
    gen.tokens_to_midi(generated_tokens, output_path=output_fn)
    print(f"\n[DONE] PulseGPT 多轨生成完毕: {output_fn}")
