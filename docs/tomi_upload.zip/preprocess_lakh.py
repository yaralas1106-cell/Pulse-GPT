"""
PulseGPT — preprocess_lakh.py
================================
解决 Lakh MIDI 数据的三大问题：
  1. 鼓组标准化：将任意 GM pitch 映射到 KICK/SNARE/HIHAT/FILL 四类
  2. 段落自动切分：基于能量分析将完整歌曲切分为 INTRO/BREAKDOWN/DROP/OUTRO
  3. 轨道过滤：只保留 DRUMS/BASS/CHORD/MELODY 四轨

用法：
  python preprocess_lakh.py --preview 3     # 只处理 3 首，打印详情供审核
  python preprocess_lakh.py --all            # 处理全部
"""

import os
import re
import glob
import argparse
import numpy as np
import pretty_midi
from collections import defaultdict

RAW_DIR = r"d:\BigData\PycharmProject\TOMI-GPT\dataset\raw"
OUT_DIR = r"d:\BigData\PycharmProject\TOMI-GPT\dataset\raw_processed"

# ──────────────────────────────────────────────────────────────────────
# 1. 鼓组标准化映射
# ──────────────────────────────────────────────────────────────────────
# GM Drum Map -> 我们的四类鼓组件
DRUM_MAP = {
    # KICK (低频打击)
    35: 'KICK', 36: 'KICK',
    
    # SNARE / CLAP (中频打击)
    37: 'SNARE', 38: 'SNARE', 39: 'SNARE', 40: 'SNARE',  # rimshot, snare, clap, electric snare
    
    # HIHAT (高频金属)
    42: 'HIHAT_CLOSED', 44: 'HIHAT_CLOSED', 46: 'HIHAT_OPEN',
    
    # FILLS / PERCUSSION (其他)
    41: 'FILL', 43: 'FILL', 45: 'FILL', 47: 'FILL', 48: 'FILL', 50: 'FILL',  # toms
    49: 'FILL', 51: 'FILL', 52: 'FILL', 53: 'FILL', 55: 'FILL', 57: 'FILL',  # cymbals
    54: 'FILL', 56: 'FILL',  # tambourine, cowbell
}

# 扩展映射：60-87 pitch 区间也是常见的打击乐/FX
for p in range(58, 88):
    if p not in DRUM_MAP:
        DRUM_MAP[p] = 'FILL'
# 极低 pitch (< 35) 视为 KICK
for p in range(20, 35):
    DRUM_MAP[p] = 'KICK'

# 标准化后的 GM pitch
CANONICAL_PITCH = {
    'KICK': 36,
    'SNARE': 38,
    'HIHAT_CLOSED': 42,
    'HIHAT_OPEN': 46,
    'FILL': 47,  # 统一用 mid tom
}


def standardize_drums(instrument):
    """将任意 GM 鼓轨标准化为 KICK/SNARE/HIHAT/FILL"""
    new_notes = []
    stats = defaultdict(int)
    
    for note in instrument.notes:
        drum_type = DRUM_MAP.get(note.pitch, 'FILL')
        new_pitch = CANONICAL_PITCH[drum_type]
        new_notes.append(pretty_midi.Note(
            velocity=note.velocity,
            pitch=new_pitch,
            start=note.start,
            end=note.end
        ))
        stats[drum_type] += 1
    
    instrument.notes = new_notes
    return stats


# ──────────────────────────────────────────────────────────────────────
# 2. 段落自动切分（基于能量密度分析）
# ──────────────────────────────────────────────────────────────────────

def compute_bar_energy(pm, bpm, n_bars):
    """计算每小节的能量（音符密度 × 平均力度）"""
    beat_dur = 60.0 / bpm
    bar_dur = beat_dur * 4
    energies = np.zeros(n_bars)
    
    for inst in pm.instruments:
        for note in inst.notes:
            bar_idx = int(note.start / bar_dur)
            if 0 <= bar_idx < n_bars:
                vel_norm = note.velocity / 127.0
                energies[bar_idx] += vel_norm
    
    # 归一化到 0-1
    if energies.max() > 0:
        energies = energies / energies.max()
    return energies


def segment_song(pm, bpm):
    """
    基于能量曲线将歌曲自动分段。
    
    逻辑：
    - 低能量开头 → INTRO
    - 能量骤降 → BREAKDOWN  
    - 能量高峰 → DROP
    - 低能量结尾 → OUTRO
    
    返回: [(struct_name, start_bar, end_bar), ...]
    """
    beat_dur = 60.0 / bpm
    bar_dur = beat_dur * 4
    total_time = pm.get_end_time()
    n_bars = max(1, int(np.ceil(total_time / bar_dur)))
    
    if n_bars < 4:
        return [('PATTERN', 0, n_bars)]
    
    energies = compute_bar_energy(pm, bpm, n_bars)
    
    # 用 4 小节窗口做平滑
    window = min(4, n_bars // 2)
    if window > 0:
        smooth = np.convolve(energies, np.ones(window)/window, mode='same')
    else:
        smooth = energies
    
    # 计算全曲的能量阈值
    median_e = np.median(smooth)
    high_thresh = median_e + 0.15  # 高能 → DROP
    low_thresh = median_e - 0.1   # 低能 → INTRO/BREAKDOWN
    
    segments = []
    
    # 策略：将歌曲按能量分为若干块
    # 先找出所有高能量区域（连续超过阈值的段）
    is_high = smooth > high_thresh
    is_low = smooth < low_thresh
    
    # 简化分段策略：按比例切分
    # INTRO: 前 15-20%
    # DROP zones: 高能量集中区域
    # BREAKDOWN: 两个 DROP 之间
    # OUTRO: 最后 10-15%
    
    intro_end = max(2, int(n_bars * 0.15))
    outro_start = min(n_bars - 2, int(n_bars * 0.85))
    
    # INTRO
    segments.append(('INTRO', 0, intro_end))
    
    # 中间段：找能量峰谷
    mid_energies = smooth[intro_end:outro_start]
    mid_len = len(mid_energies)
    
    if mid_len >= 8:
        # 将中间段分成 2-3 个块
        mid_median = np.median(mid_energies)
        
        # 找波谷点（BREAKDOWN）
        drop_sections = []
        breakdown_sections = []
        
        current_type = None
        block_start = 0
        
        for i in range(mid_len):
            e = mid_energies[i]
            new_type = 'DROP' if e > mid_median else 'BREAKDOWN'
            
            if new_type != current_type:
                if current_type is not None and (i - block_start) >= 2:
                    abs_start = intro_end + block_start
                    abs_end = intro_end + i
                    if current_type == 'DROP':
                        drop_sections.append((abs_start, abs_end))
                    else:
                        breakdown_sections.append((abs_start, abs_end))
                block_start = i
                current_type = new_type
        
        # 最后一个块
        if current_type and (mid_len - block_start) >= 2:
            abs_start = intro_end + block_start
            abs_end = intro_end + mid_len
            if current_type == 'DROP':
                drop_sections.append((abs_start, abs_end))
            else:
                breakdown_sections.append((abs_start, abs_end))
        
        # 交替添加 BREAKDOWN/DROP（各最多 3 个）
        all_mid = []
        for s, e in breakdown_sections[:3]:
            all_mid.append(('BREAKDOWN', s, e))
        for s, e in drop_sections[:3]:
            all_mid.append(('DROP', s, e))
        
        # 按起始位置排序
        all_mid.sort(key=lambda x: x[1])
        
        if not all_mid:
            # fallback：整个中间段作为 DROP
            segments.append(('DROP', intro_end, outro_start))
        else:
            # 限制 section 编号
            section_count = {'BREAKDOWN': 0, 'DROP': 0}
            for stype, s, e in all_mid:
                if section_count[stype] < 3:
                    segments.append((stype, s, e))
                    section_count[stype] += 1
    else:
        # 中间段太短，直接标为 DROP
        segments.append(('DROP', intro_end, outro_start))
    
    # OUTRO
    segments.append(('OUTRO', outro_start, n_bars))
    
    return segments


# ──────────────────────────────────────────────────────────────────────
# 3. 轨道过滤 & 乐器分类
# ──────────────────────────────────────────────────────────────────────

def classify_instrument(inst):
    """分类乐器为 DRUMS/BASS/CHORD/MELODY 之一"""
    if inst.is_drum:
        return 'DRUMS'
    
    name = inst.name.upper() if inst.name else ''
    prog = inst.program
    
    # 按名称优先
    bass_kw = ['BASS', '808', 'SUB']
    melody_kw = ['LEAD', 'MELODY', 'SYNTH LEAD', 'SOLO', 'VOCAL', 'VOICE']
    chord_kw = ['PAD', 'CHORD', 'STRING', 'ORGAN', 'PIANO', 'KEY', 'BRASS', 'ORCH']
    
    if any(k in name for k in bass_kw):
        return 'BASS'
    if any(k in name for k in melody_kw):
        return 'MELODY'
    if any(k in name for k in chord_kw):
        return 'CHORD'
    
    # 按 GM Program
    if 32 <= prog <= 39:
        return 'BASS'
    if prog in range(0, 8) or prog in range(16, 32) or prog in range(48, 64) or prog in range(88, 96):
        return 'CHORD'
    if prog in range(80, 88):
        return 'MELODY'
    
    # 按音高
    if inst.notes:
        avg_pitch = np.mean([n.pitch for n in inst.notes])
        if avg_pitch < 48:
            return 'BASS'
        elif avg_pitch > 72:
            return 'MELODY'
    
    return 'CHORD'


# ──────────────────────────────────────────────────────────────────────
# 4. 主处理函数
# ──────────────────────────────────────────────────────────────────────

def estimate_bpm(pm):
    try:
        tempos = pm.get_tempo_changes()[1]
        if len(tempos) > 0:
            bpm = int(round(np.median(tempos)))
            if 60 <= bpm <= 200:
                return bpm
    except:
        pass
    return 120


def detect_key(pm):
    NOTE_NAMES = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B']
    pitch_hist = np.zeros(12)
    for inst in pm.instruments:
        if inst.is_drum:
            continue
        for note in inst.notes:
            pitch_hist[note.pitch % 12] += 1
    if pitch_hist.sum() == 0:
        return 'C', 'MINOR'
    root = int(np.argmax(pitch_hist))
    minor_third = pitch_hist[(root + 3) % 12]
    major_third = pitch_hist[(root + 4) % 12]
    mode = 'MINOR' if minor_third > major_third else 'MAJOR'
    return NOTE_NAMES[root], mode


def process_one(midi_path, output_dir, preview=False):
    """处理单个 MIDI 文件，输出分段后的多个文件"""
    try:
        pm = pretty_midi.PrettyMIDI(midi_path)
    except:
        return []
    
    end_time = pm.get_end_time()
    if end_time < 10 or end_time > 600:
        return []
    
    bpm = estimate_bpm(pm)
    root, mode = detect_key(pm)
    beat_dur = 60.0 / bpm
    bar_dur = beat_dur * 4
    
    # 分类所有轨道（只保留 DRUMS/BASS/CHORD/MELODY）
    track_map = {}
    for inst in pm.instruments:
        if not inst.notes:
            continue
        t_type = classify_instrument(inst)
        if t_type not in track_map:
            track_map[t_type] = []
        track_map[t_type].append(inst)
    
    if len(track_map) < 2:
        return []
    
    # 标准化鼓组
    drum_stats = {}
    if 'DRUMS' in track_map:
        for dinst in track_map['DRUMS']:
            drum_stats = standardize_drums(dinst)
    
    # 自动分段
    segments = segment_song(pm, bpm)
    
    if preview:
        basename = os.path.basename(midi_path)
        print(f"\n{'─'*70}")
        print(f"  File: {basename}")
        print(f"  BPM: {bpm} | Key: {root}_{mode} | Duration: {end_time:.1f}s | Bars: {int(np.ceil(end_time/bar_dur))}")
        print(f"  Tracks: {list(track_map.keys())}")
        if drum_stats:
            print(f"  Drums: {dict(drum_stats)}")
        print(f"  Segments:")
        for stype, s_bar, e_bar in segments:
            dur = (e_bar - s_bar) * bar_dur
            print(f"    {stype:12s}  bars {s_bar:3d}-{e_bar:3d}  ({dur:.1f}s)")
    
    # 导出每个段落
    results = []
    basename = os.path.splitext(os.path.basename(midi_path))[0]
    
    # 从原文件名提取 genre
    genre = 'EDM'
    if basename.startswith('LAKH_'):
        parts = basename.split('_')
        if len(parts) > 1:
            genre = parts[1]
    elif 'HOUSE' in basename.upper():
        genre = 'HOUSE'
    elif 'TECHNO' in basename.upper():
        genre = 'TECHNO'
    
    section_counter = defaultdict(int)
    
    for stype, s_bar, e_bar in segments:
        section_counter[stype] += 1
        sec_num = section_counter[stype]
        if sec_num > 3:
            continue
        
        # 时间范围
        t_start = s_bar * bar_dur
        t_end = e_bar * bar_dur
        
        # 创建新 MIDI
        seg_pm = pretty_midi.PrettyMIDI(initial_tempo=bpm)
        has_notes = False
        
        for t_type in ['DRUMS', 'BASS', 'CHORD', 'MELODY']:
            if t_type not in track_map:
                continue
            
            new_inst = pretty_midi.Instrument(
                program=0 if t_type == 'DRUMS' else track_map[t_type][0].program,
                is_drum=(t_type == 'DRUMS'),
                name=t_type
            )
            
            for orig_inst in track_map[t_type]:
                for note in orig_inst.notes:
                    if t_start <= note.start < t_end:
                        new_note = pretty_midi.Note(
                            velocity=note.velocity,
                            pitch=note.pitch,
                            start=note.start - t_start,
                            end=min(note.end, t_end) - t_start
                        )
                        new_inst.notes.append(new_note)
                        has_notes = True
            
            if new_inst.notes:
                seg_pm.instruments.append(new_inst)
        
        if not has_notes or len(seg_pm.instruments) < 1:
            continue
        
        # 文件名
        safe_base = re.sub(r'[^A-Za-z0-9_]', '', basename)[:40]
        out_name = f"{genre}_{safe_base}_{stype}{sec_num}_{bpm}.mid"
        out_path = os.path.join(output_dir, out_name)
        seg_pm.write(out_path)
        
        n_tracks = len(seg_pm.instruments)
        n_notes = sum(len(i.notes) for i in seg_pm.instruments)
        track_names = [i.name for i in seg_pm.instruments]
        
        results.append({
            'file': out_name,
            'struct': stype,
            'section': sec_num,
            'tracks': track_names,
            'n_notes': n_notes,
            'bars': e_bar - s_bar,
        })
        
        if preview:
            print(f"    -> {out_name}  ({n_notes} notes, {n_tracks} tracks: {track_names})")
    
    return results


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--preview', type=int, default=0, help='Preview N files without batch processing')
    parser.add_argument('--all', action='store_true', help='Process all files')
    args = parser.parse_args()
    
    os.makedirs(OUT_DIR, exist_ok=True)
    
    # 收集所有 LAKH_ 文件
    files = sorted([
        os.path.join(RAW_DIR, f) 
        for f in os.listdir(RAW_DIR) 
        if f.endswith('.mid') and f.startswith('LAKH_')
    ])
    
    print(f"\n{'='*70}")
    print(f"  Lakh MIDI Preprocessor | Total: {len(files)} files")
    print(f"{'='*70}")
    
    if args.preview > 0:
        print(f"\n  [PREVIEW MODE] 处理前 {args.preview} 首...")
        total_segments = 0
        for f in files[:args.preview]:
            results = process_one(f, OUT_DIR, preview=True)
            total_segments += len(results)
        print(f"\n  [SUMMARY] {args.preview} 首 -> {total_segments} 个段落")
    
    elif args.all:
        from tqdm import tqdm
        total_segments = 0
        total_files = 0
        for f in tqdm(files, desc="Processing"):
            results = process_one(f, OUT_DIR, preview=False)
            if results:
                total_files += 1
                total_segments += len(results)
        print(f"\n  [DONE] {total_files}/{len(files)} files -> {total_segments} segments")
        print(f"  [OUT]  {OUT_DIR}")
    
    else:
        print("  Usage: --preview N  or  --all")


if __name__ == "__main__":
    main()
